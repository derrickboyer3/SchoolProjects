// File: mufs_repl.c
// Author: Chad Hogg
// Program that experiments with the MU FileSystem library.
// Part of the handout for mustorage2 lab in CSCI380.

#include "mufs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define BUFFER_SIZE 4096

// Prints instructions for how to run the program.
void
printInstructions ();

// Prints a summary of the filesystem.
void
printFS (MUDISK* disk);

int
main (int argc, char* argv[])
{
  // Confirm that we got a filename (and nothing else).
  if (argc != 2) {
    fprintf (stderr, "Usage: %s <filename>\n", argv[0]);
    exit (EXIT_FAILURE);
  }

  printInstructions ();
  char buffer[BUFFER_SIZE];

  // Open the disk.
  MUDISK* disk = muDisk_open (argv[1]);
  
  // Ensure that the disk was able to be opened.
  if (disk == NULL) {
    fprintf (stderr, "MUError: %d\n", muerrno);
    exit (EXIT_FAILURE);
  }

  // If desired, format disk.
  printf("Re-format disk [warning: destructive] (y/n): ");
  fgets (buffer, BUFFER_SIZE, stdin);
  if (strlen (buffer) > 0 && buffer[0] == 'y') {
    muFS_format (disk);
  }

  // Load the filesystem.
  MUFS* fs = muFS_open (disk);

  // Ensure that the filesystem was able to be loaded.
  if (fs == NULL) {
    fprintf(stderr, "MUError: %d\n", muerrno);
    exit (EXIT_FAILURE);
  }

  // Loop until the user decides to quit.
  while (true) {
    bool good = false;
    printf("mufs_repl> ");
    fgets (buffer, BUFFER_SIZE, stdin);
    char* first = strtok (buffer, " \n\t");
    char* second = (first == NULL ? NULL : strtok (NULL, " \n\t"));
    char* third = (second == NULL ? NULL : strtok (NULL, " \n\t"));
    char* fourth = (third == NULL ? NULL : strtok (NULL, " \n\t"));
    char* fifth = (fourth == NULL ? NULL : strtok (NULL, " \n\t"));
    if (first != NULL) {
      if (strcmp (first, "q") == 0 && second == NULL) {
        // quit
        break;
      }
      else if (strcmp (first, "p") == 0 && second == NULL) {
        // print
        printFS (disk);
        good = true;
      }
      else if (strcmp (first, "m") == 0 && second == NULL) {
        // make (create)
        good = true;
        char junk[MUFS_INODE_RESERVED];
        memset (junk, 0, MUFS_INODE_RESERVED);
        MUFILE* file = muFS_createFile (fs, junk);
        if (file == NULL) {
          fprintf (stderr, "MUError: %d\n", muerrno);
          return EXIT_FAILURE;
        }
        printf ("Created a new file with inode %d\n", muFS_getINodeNum (file));
        muFS_closeFile (fs, file);
      }
      else if (strcmp (first, "d") == 0 && second != NULL && third == NULL) {
        // delete
        char* end;
        int inodeNum = strtol (second, &end, 10);
        if (*end == '\0' && end != second)
        {
          good = true;
          int result = muFS_deleteFile (fs, inodeNum);
          if (result == -1) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          printf ("Deleted file with inode %d\n", inodeNum);
        }
      }
      else if(strcmp (first, "r") == 0 && second != NULL && third != NULL && fourth == NULL) {
        // read block
        char* end, * end2;
        int iNodeNum = strtol (second, &end, 10);
        int blockNum = strtol (third, &end2, 10);
        if (*end == '\0' && *end2 == '\0') {
          good = true;
          char buffer[MUDISK_BLOCK_SIZE + 1];
          MUFILE* file = muFS_openFile (fs, iNodeNum);
          if (file == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          if (muFS_readFileBlock (fs, file, blockNum, buffer) == -1) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          muFS_closeFile (fs, file);
          buffer[MUDISK_BLOCK_SIZE] = '\0';
          printf("%s\n", buffer);
        }
      }
      else if(strcmp (first, "w") == 0 && second != NULL && third != NULL && fourth != NULL && fifth == NULL) {
        char* end, * end2;
        int iNodeNum = strtol (second, &end, 10);
        int blockNum = strtol (third, &end2, 10);
        if (*end == '\0' && *end2 == '\0') {
          MUFILE* file = muFS_openFile (fs, iNodeNum);
          if (file == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          good = true;
          char buffer[MUDISK_BLOCK_SIZE];
          char* mover = fourth;
          for (int index = 0; index < MUDISK_BLOCK_SIZE; ++index)
          {
            if (*mover == '\0')
            {
              mover = fourth;
            }
            buffer[index] = *mover;
            ++mover;
          }
          if (muFS_writeFileBlock (fs, file, blockNum, buffer) == -1) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          muFS_closeFile (fs, file);
        }
      }
      if (!good)
      {
        printf ("This command was not understood -- no action has been taken.\n");
      }
    }
  }

  // Unload everything.
  muFS_close (fs);
  fs = NULL;
  muDisk_close (disk);
  disk = NULL;

  return EXIT_SUCCESS;
}

void
printInstructions ()
{
  printf ("Welcome to the MUFS REPL.\n");
  printf ("Commands: \n");
  printf ("- q: Quits the program.\n");
  printf ("- p: Prints the filesystem.\n");
  printf ("- m: Makes a new file.\n");
  printf ("- d <#>: Delete file with inode number #.\n");
  printf ("- r <#1> <#2>: Reads block number #2 from file with inode #1 and dumps to stdout.\n");
  printf ("- w <#1> <#2> <pattern>: Writes pattern to block number #2 from file with inode #1, tiling as necessary.\n");
}

// This is supposed to be a private, hidden detail inside of mufs.c.
// I copied it here so that we can examine inodes without depending on your code at all.
// If the format we use for inodes changes, this will break horribly.
struct fakeINode {
    uint8_t used;
    uint8_t reserved[MUFS_INODE_RESERVED];
    uint32_t directBlocks[MUFS_NUM_DIRECT_BLOCKS];
};

void
printFS (MUDISK* disk)
{
  char superblock[MUDISK_BLOCK_SIZE];
  uint8_t freeblockMap[MUDISK_BLOCK_SIZE];
  struct fakeINode inodes[MUFS_INODES_PER_BLOCK];
  char data[MUDISK_BLOCK_SIZE];

  muDisk_read (disk, 0, superblock);
  printf ("The superblock starts with %s\n", superblock);

  muDisk_read (disk, 1, freeblockMap);
  printf ("The following block numbers are in use: ");
  for (int i = 0; i < MUDISK_BLOCK_COUNT; ++i) {
    if (freeblockMap[i] == MUFS_BLOCK_USED) {
      printf ("%d ", i);
    }
  }
  printf ("\n");

  bool atLeastOne = false;
  for (int blk = MUFS_FIRSTINODEBLOCK_NUMBER; blk < MUFS_FIRSTDATABLOCK_NUMBER; ++blk) {
    muDisk_read (disk, blk, inodes);
    for (int nd = 0; nd < MUFS_INODES_PER_BLOCK; ++nd) {
      if (inodes[nd].used == MUFS_INODE_USED) {
        atLeastOne = true;
        printf ("File #%d uses blocks ", (blk - MUFS_FIRSTINODEBLOCK_NUMBER) * MUFS_INODES_PER_BLOCK + nd);
        for (int i = 0; i < MUFS_NUM_DIRECT_BLOCKS; ++i) {
          if (inodes[nd].directBlocks[i] == 0) {
            printf ("_ ");
          }
          else {
            printf ("%d ", inodes[nd].directBlocks[i]);
          }
        }
        printf ("\n");
      }
    }
  }
  if (!atLeastOne) {
    printf ("The filesystem contains no files.\n");
  }

  for (int blk = MUFS_FIRSTDATABLOCK_NUMBER; blk < MUDISK_BLOCK_COUNT; ++blk) {
    if (freeblockMap[blk] == MUFS_BLOCK_USED) {
      muDisk_read (disk, blk, data);
      printf ("Block %d contains \"%c%c%c%c ...\"\n", blk, data[0], data[1], data[2], data[3]);
    }
  }
}