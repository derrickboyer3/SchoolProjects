// File: muerrno.h
// Author: Chad Hogg
// A library for noting and retrieving errors.
// Part of handout for mustorage1 lab in CSCI380, also used in future labs.

#ifndef MUERRNO_H
#define MUERRNO_H

// The global variable into which our functions will write error codes.
extern int muerrno;

//// Start of errors for MU Virtual Disk Library (MUDISK) ////

// Attempt to open a real file as a virtual disk when that real file
//   either does not exist or is not both readable and writable.
#define ERR_MUDISK_NO_SUCH_DISK 1

// Attempt to open a real file as a virtual disk when the real file
//   is not the correct size.
#define ERR_MUDISK_WRONG_DISK_SIZE 2

// Attempt to read or write from an invalid block number.
#define ERR_MUDISK_INVALID_BLOCK_NUM 3

// Attempt to create a virtual disk where there is already a file.
#define ERR_MUDISK_FILE_ALREADY_EXISTS 4

// Attempt to create a new disk file that cannot be created.
#define ERR_MUDISK_CREATION_FAILURE 5


//// Start of errors for MU File System Library (MUFS). ////

// Attempt to load a filesystem with the wrong identifier.
#define ERR_MUFS_WRONG_VERSION 100

// Attempt to access an inode that does not exist.
#define ERR_MUFS_INVALID_INODE_NUM 101

// Attempt to open an inode that is not in use.
#define ERR_MUFS_INODE_NOT_USED 102

// Attempt to create a file when there are no available inodes.
#define ERR_MUFS_NO_AVAILABLE_INODES 103

// Attempt to read/write a block number that is not less than MUFS_NUM_DIRECT_BLOCKS.
#define ERR_MUFS_INVALID_BLOCK_NUM 104

// Attempt to read a block that has not been allocated yet.
#define ERR_MUFS_READ_UNALLOCATED 105

// Attempt to write an unallocated block when no free blocks exist.
#define ERR_MUFS_NO_AVAILABLE_BLOCKS 106

// Attempt to delete a file that is open.
#define ERR_MUFS_FILE_IS_OPEN 107


//// Start of errors for MU Directory Library (MUDIR). ////

// Attempt to search in a directory for a file that is not found.
#define ERR_MUDIR_FILE_NOT_FOUND 200

// Attempt to treat a regular file as a directory.
#define ERR_MUDIR_NOT_DIRECTORY 201

// Attempt to link a file to a directory that already contains a file with that name.
#define ERR_MUDIR_NAME_ALREADY_USED 202

// Attempt to link a file into a full directory.
#define ERR_MUDIR_FULL_DIR 203


//// Start of errors for MU File System Library (MUFS). ////

// Attempt to interact with a file in a way prohibited by its permissions.
#define ERR_MUNIX_PERMISSION 300

// Attempt to open a file when maximum open files has been reached.
#define ERR_MUNIX_TOO_MANY_OPEN_FILES 301

// Function was passed a file descriptor that is not in use.
#define ERR_MUNIX_BAD_DESCRIPTOR 302


/*
#define MU_E_BAD_NAME 1
#define MU_E_DOES_NOT_EXIST 2
#define MU_E_NOT_DIR 3
#define MU_E_PERMISSION 4
#define MU_E_NOT_REG 5
#define MU_E_FULL_TABLE 6
#define MU_E_INVALID_FD 7
#define MU_E_NO_SUCH_USER 8
#define MU_E_NO_SUCH_GROUP 9
#define MU_E_NOT_MEMBER 10
*/

#endif//MUERRNO_H
