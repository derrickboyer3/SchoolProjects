// File: mudisk.c
// Author: Chad Hogg & Derrick Boyer
// Implementation of Millersville University Virtual Disk library.
// Part of the handout for mustorage1 lab in CSCI380.

#include "muerrno.h"
#include "mudisk.h"

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// All of the information about a specific virtual disk.
struct muDisk
{
  // The real file descriptor for the real file that we are treating as a virtual disk.
  int fd;
  // The path to the real file.
  char path[MUDISK_MAX_PATH_LENGTH];
};


MUDISK*
muDisk_open (const char* pathToRealFile)
{
  // Allocate enough space on the heap to store an MUDISK.
  MUDISK* disk = (MUDISK*)malloc(sizeof(MUDISK));
  if (disk == NULL) {
      perror("Failed to allocate memory for MUDISK");
      return NULL;
  }

  // Attempt to open the real file and store its descriptor.
  disk->fd = open(pathToRealFile, O_RDWR);
  if (disk->fd == -1) {
      // If unsuccessful: deallocate, set muerrno, and return NULL.
      muerrno = ERR_MUDISK_NO_SUCH_DISK;
      perror("Failed to open the real file");
      free(disk);
      return NULL;
  }

  // Look up metadata about the real file.
  // If incorrect size: close file, deallocate, set muerrno, and return NULL.
  struct stat st;
  if (fstat(disk->fd, &st) == -1) {
      perror("Failed to get file information");
      close(disk->fd);
      free(disk);
      return NULL;
  }
  if (st.st_size != MUDISK_DISK_SIZE) {
      muerrno = ERR_MUDISK_WRONG_DISK_SIZE;
      fprintf(stderr, "Invalid disk size\n");
      close(disk->fd);
      free(disk);
      return NULL;
  }

  // Copy the name into the struct.
  strncpy(disk->path, pathToRealFile, MUDISK_MAX_PATH_LENGTH);
  disk->path[MUDISK_MAX_PATH_LENGTH - 1] = '\0';

  // Return the disk.
  return disk;
}



void
muDisk_close (MUDISK* disk)
{
  // Check for NULL
  if (disk == NULL) {
        return;
  }

  // Close the real file that stores the virtual disk.
  close(disk->fd);

  // Release the heap memory that was storing the MUDISK.
  free(disk);
}



int
muDisk_read (MUDISK* disk, uint32_t blockNum, void* buffer)
{
  // If block number is out of bounds: set muerrno, return -1.
  if (blockNum > MUDISK_BLOCK_COUNT) {
    muerrno = ERR_MUDISK_INVALID_BLOCK_NUM;
    perror("Invalid block number");
    return -1;
  }

  // Seek to proper location
  off_t offset = blockNum * MUDISK_BLOCK_SIZE;
  if (lseek(disk->fd, offset, SEEK_SET) == -1) {
    perror("Failed to seek in the file");
    return -1;
  }

  // Read the block
  ssize_t bytes_read = read(disk->fd, buffer, MUDISK_BLOCK_SIZE);
  if (bytes_read == -1) {
    perror("Failed to read from file");
    return -1;
  }

  // Return successfully
  return bytes_read;
}



int
muDisk_write (MUDISK* disk, uint32_t blockNum, void* buffer)
{
  // If block number is out of bounds: set muerrno, return -1.
  if (blockNum > MUDISK_BLOCK_COUNT) {
    muerrno = ERR_MUDISK_INVALID_BLOCK_NUM;
    perror("Invalid block number");
    return -1;
  }

  // Seek to proper location
  off_t offset = blockNum * MUDISK_BLOCK_SIZE;
  if (lseek(disk->fd, offset, SEEK_SET) == -1) {
      perror("Failed to seek in the file");
      return -1;
  }

  // Write the block
  ssize_t bytes_written = write(disk->fd, buffer, MUDISK_BLOCK_SIZE);
  if (bytes_written == -1) {
      perror("Failed to write to file");
      return -1;
  }

  // Return successfully
  return bytes_written;
}


int
muDisk_create (const char* pathToRealFile)
{
  // Attempt to create the file, with its owner able to read/write it and everyone else able to read it.
  int fd = open(pathToRealFile, O_CREAT | O_EXCL | O_WRONLY, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (fd == -1) {
    // If failed because file already existed: set muerrno, return -1.
    if (errno == EEXIST) {
      muerrno = ERR_MUDISK_FILE_ALREADY_EXISTS;
    }
    // If failed for some other reason: set muerrno and return -1.
    else {
    muerrno = ERR_MUDISK_CREATION_FAILURE;
    }
    perror("Failed to create the file");
    return -1;
  }

  // Write MUDISK_BLOCK_COUNT blocks of MUDISK_BLOCK_SIZE containing all zeroes to file, so that it has the correct size.
  char buffer[MUDISK_BLOCK_SIZE] = {0};
  for (int i = 0; i < MUDISK_BLOCK_COUNT; ++i) {
    ssize_t bytes_written = write(fd, buffer, MUDISK_BLOCK_SIZE);
    if (bytes_written == -1) {
      perror("Failed to write to file");
      close(fd);
      unlink(pathToRealFile);  // Delete the file on failure
      return -1;
    }
  }

  // Close the file
  close(fd);

  // Return successfully
  return 0;

}
