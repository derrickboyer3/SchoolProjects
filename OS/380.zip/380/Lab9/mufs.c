// File: mufs.c
// Author: Chad Hogg && Derrick Boyer
// Implementation details of the Millersville University File System.
// Part of handout for mustorage2 lab in CSCI380.

#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>

#include "mudisk.h"
#include "mufs.h"

// The structure of the filesystem superblock.
struct superBlock
{
    // An 8-character identifier -- should be VERSION10.
    char identifier[MUFS_IDENTIFIER_LENGTH];
    // Space reserved for potential use in later versions of the filesystem.
    char reserved[MUDISK_BLOCK_SIZE - MUFS_IDENTIFIER_LENGTH];
};

// The structure of the free block map.
struct freeBlockMap
{
    // A byte per block that contains either MUFS_BLOCK_USED or MUFS_BLOCK_AVAILABLE.
    uint8_t isUsed[MUDISK_BLOCK_SIZE];
};

// The structure of an inode.
struct iNode
{
    // Whether or not this inode is used.
    uint8_t used;
    // Space reserved for storing metadata for the OS.
    uint8_t reserved[MUFS_INODE_RESERVED];
    // The numbers of the first 10 data blocks.
    uint32_t directBlocks[MUFS_NUM_DIRECT_BLOCKS];
};

// The information that we need to keep in memory about any open files.
struct muFile
{
    // The iNode.
    struct iNode inode;
    // Which inode this is.
    unsigned int iNodeNumber;
    // The number of outstanding references to this file.
    unsigned int refCount;
};

// The information that we store about a filesystem.
struct muFS
{
    // The disk on which this filesystem resides.
    struct muDisk* disk;
    // An in-memory cache of the filesystem's superblock.
    //   If modified, need to write new version back to disk.
    struct superBlock superBlock;
    // An in-memory cache of the filesystem's free block list.
    //   If modified, need to write new version back to disk.
    struct freeBlockMap freeBlocks;
    // An in-memory cache of information about files that are currently open.
    //   If an open file's metadata is modified, its inode will need to be written back to disk.
    //   If a file is not open, its corresponding location in the array should be NULL.
    struct muFile* files[MUFS_INODE_COUNT];
};

// Check that inodes are the expected size.
static_assert (MUFS_INODE_SIZE == sizeof (struct iNode), "Incorrect inode size.");
// Check that the right number of blocks are used for storing inodes.
static_assert (MUFS_FIRSTDATABLOCK_NUMBER - MUFS_FIRSTINODEBLOCK_NUMBER == MUFS_INODE_COUNT / MUFS_INODES_PER_BLOCK, "Incorrect number of blocks for storing inodes.");



// Reads an inode from the disk.
// (Private implementation detail.)
// Parameters: 
// - fs [in] A handle for the filesystem that should be operated on.
// - iNodeNumber [in] The number of the requested index node.
// - node [out] A pointer to the memory location where the inode contents should be written.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - 0 <= iNodeNum < MUFS_INODE_COUNT.
// - node points to at least MUFS_INODE_SIZE bytes of free memory.
// Postconditions:
// - The location pointed to by node contains a copy of the requested inode from the virtual disk.
void
muFS_internal_readINode (MUFS* fs, uint16_t iNodeNum, struct iNode* node)
{
    // Sanity check: iNodeNum < MUFS_INODE_COUNT
    assert(iNodeNum < MUFS_INODE_COUNT);
    assert(iNodeNum >= 0);

    // Calculate which block number this inode can be found in.
    uint32_t blockNumber = MUFS_FIRSTINODEBLOCK_NUMBER + (iNodeNum / MUFS_INODES_PER_BLOCK);
    
    // Calculate the offset within that block where this inode is located.
    uint32_t offset = (iNodeNum % MUFS_INODES_PER_BLOCK) * MUFS_INODE_SIZE;

    // Load the requested block from the disk.
    char buffer[MUDISK_BLOCK_SIZE];
    muDisk_read(fs->disk, blockNumber, buffer);

    // Copy the relevant part of that block into node.
    memcpy(node, buffer + offset, MUFS_INODE_SIZE);
}


// Writes an inode to the disk.
// (Private implementation detail.)
// Parameters: 
// - fs [in] A handle for the filesystem that should be operated on.
// - iNodeNumber [in] The number of the index node that is being written.
// - node [out] A pointer to the memory location containing the inode data.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - 0 <= iNodeNum < MUFS_INODE_COUNT.
// - node points to the data that should be written.
// Postconditions:
// - The inode has been written to the correct location on disk.
void
muFS_internal_writeINode (MUFS* fs, uint16_t iNodeNum, struct iNode* node)
{
    // Sanity check: iNodeNum < MUFS_INODE_COUNT.
    assert(iNodeNum < MUFS_INODE_COUNT);
    assert(iNodeNum >= 0);

    // Calculate which block number this inode can be found in.
    uint32_t blockNumber = MUFS_FIRSTINODEBLOCK_NUMBER + (iNodeNum / MUFS_INODES_PER_BLOCK);
    
    // Calculate the offset within that block where this inode is located.
    uint32_t offset = (iNodeNum % MUFS_INODES_PER_BLOCK) * MUFS_INODE_SIZE;

    // Load the requested block from the disk.
    char buffer[MUDISK_BLOCK_SIZE];
    muDisk_read(fs->disk, blockNumber, buffer);

    // Copy the node data into the appropriate place in the block.
    memcpy(buffer + offset, node, MUFS_INODE_SIZE);

    // Write the block back to disk.
    muDisk_write(fs->disk, blockNumber, buffer);
}


MUFS*
muFS_open (MUDISK* disk)
{
    // Allocate space on the heap to store an MUFS.
    MUFS* fs = malloc(MUDISK_BLOCK_COUNT * MUDISK_BLOCK_SIZE);
    if (fs == NULL) {
        perror("Failed to allocate memory for the muFS on muFS_open.");
        return NULL;
    }

    // Set the disk.
    fs->disk = disk;

    // Read the superblock from the disk to its in-memory cache.
    muDisk_read(fs->disk, MUFS_SUPERBLOCK_NUMBER, &(fs->superBlock));

    // If version string does not match: deallocate, set muerrno, return NULL.
    if(strcmp(fs->superBlock.identifier, MUFS_VERSION10)) {
        free(fs);
        muerrno = ERR_MUFS_WRONG_VERSION;
    }

    // Read the free block list from the disk to its in-memory cache.
    muDisk_read(fs->disk, MUFS_FREEBLOCKMAP_NUMBER, &(fs->freeBlocks));

    // Initialize the open file cache to contain no files.
    for (unsigned int i = 0; i < MUDISK_BLOCK_SIZE; i++) {
        fs->files[i] = NULL;
    }

    // Return the initialized filesystem.
    return fs;
}


void
muFS_close (MUFS* fs)
{
    // Close any files that are still open.
    for (int i = 0; i < MUFS_INODE_COUNT; i++) {
        if (fs->files[i] != NULL) {
            muFS_closeFile(fs, fs->files[i]);
        }
    }

    // Free the heap space used to store the filesystem.
    free(fs);
}


MUFILE*
muFS_openFile (struct muFS* fs, uint16_t iNodeNum)
{
    // If inode number is invalid: set muerrno and return NULL.
    if (iNodeNum > MUFS_INODE_COUNT || iNodeNum < 0) {
        muerrno = ERR_MUFS_INVALID_INODE_NUM;
        return NULL;
    }

    // If this file is already open: increment reference counter and return existing pointer.
    if (fs->files[iNodeNum] != NULL) {
        fs->files[iNodeNum]->refCount++;
        return fs->files[iNodeNum];
    }

    // Allocate space to store file info on heap.
    struct muFile* file = malloc(MUFS_MAX_FILE_SIZE);
    if (file == NULL) {
        perror("Failed to allocate memory for the new file on muFS_openFile.");
        return NULL;
    }

    // Load the file's inode.
    muFS_internal_readINode(fs, iNodeNum, &(file->inode));

    // If inode is not in use: set muerrno and return NULL.
    if (file->inode.used != MUFS_INODE_USED) {
        muerrno = ERR_MUFS_INODE_NOT_USED;
        return NULL;
    }

    // Set the reference count to 1.
    file->refCount = 1;

    // Set the inode number.
    file->iNodeNumber = iNodeNum;

    // Store the file in the appropriate slot in the in-memory cache.
    fs->files[iNodeNum] = file;

    // Return the file.
    return file;
}


void
muFS_closeFile (MUFS* fs, MUFILE* file)
{
    // Decrement the reference count.
    file->refCount--;

    // If the reference count is now 0: deallocate and remove from cache.
    if (file->refCount == 0) {
        fs->files[file->iNodeNumber] = NULL;
        free(file);
    }
}


MUFILE*
muFS_createFile (MUFS* fs, void* metadata)
{
    // Find an unused inode.
    uint16_t iNodeNum;
    for (iNodeNum = 0; iNodeNum < MUFS_INODE_COUNT; iNodeNum++) {
        struct iNode loopNode;
        muFS_internal_readINode(fs, iNodeNum, &loopNode);
        if (loopNode.used == 0) {
            break;
        }
    }
    
    // If no such inode could be found: set muerrno, return NULL.
    if (iNodeNum == MUFS_INODE_COUNT) {
        muerrno = ERR_MUFS_NO_AVAILABLE_INODES;
        return NULL;
    }

    // Set the inode to used.
    struct iNode temp;
    muFS_internal_readINode(fs, iNodeNum, &temp);
    temp.used = 1;

    // Set the file's reserved metadata.
    memcpy(temp.reserved, metadata, MUFS_INODE_RESERVED);

    // Write the modified inode back to disk.
    muFS_internal_writeINode(fs, iNodeNum, &temp);

    // Open and return the file.
    return muFS_openFile(fs, iNodeNum);
}


void
muFS_readMetadata (MUFS* fs, MUFILE* file, void* metadata)
{
    // Copy the data from the inode into the parameter.
    memcpy(metadata, file->inode.reserved, MUFS_INODE_RESERVED);
}


void
muFS_writeMetadata (MUFS* fs, MUFILE* file, void* metadata)
{
    // Copy the data from the parameter into the inode.
    memcpy(file->inode.reserved, metadata, MUFS_INODE_RESERVED);

    // Write the modified inode to disk.
    muFS_internal_writeINode(fs, file->iNodeNumber, &(file->inode));
}


int
muFS_readFileBlock (MUFS* fs, MUFILE* file, uint32_t blockNum, void* buffer)
{
    // If blockNum is not a valid block number: set muerrno, return -1.
    if (blockNum < 0 || blockNum >= MUFS_NUM_DIRECT_BLOCKS) {
        muerrno = ERR_MUFS_INVALID_BLOCK_NUM;
        return -1;
    }

    // If requested block has not been allocated: set muerrno, return -1.
    if (file->inode.directBlocks[blockNum] == 0) {
        muerrno = ERR_MUFS_READ_UNALLOCATED;
        return -1;
    }

    // Read the appropriate block.
    ssize_t bytes_read = muDisk_read(fs->disk, file->inode.directBlocks[blockNum], buffer);

    // Return succesfully.
    return bytes_read;
}


int
muFS_writeFileBlock (MUFS* fs, MUFILE* file, uint32_t blockNum, void* buffer)
{
    // If blockNum is not a valid block number: set muerrno, return -1.
    if (blockNum < 0 || blockNum >= MUDISK_BLOCK_COUNT) {
        muerrno = ERR_MUFS_INVALID_BLOCK_NUM;
        return -1;
    }

    // If that block has not yet been allocated:
    if (file->inode.directBlocks[blockNum] == 0) {
        // Find the first unallocated block.
        unsigned int first_unallocated = 0;
        for (unsigned int i = MUFS_FIRSTDATABLOCK_NUMBER; i < MUDISK_BLOCK_COUNT; i++) {
            if (fs->freeBlocks.isUsed[i] == MUFS_BLOCK_AVAILABLE) {
                first_unallocated = i;
                break;
            }
        }

        // If no such unallocated block exists: set muerrno and return -1.
        if (first_unallocated == MUDISK_BLOCK_COUNT) {
            muerrno = ERR_MUFS_NO_AVAILABLE_BLOCKS;
            return -1;
        }

        // Allocate it to this file.
        file->inode.directBlocks[blockNum] = first_unallocated;
        fs->freeBlocks.isUsed[first_unallocated] = MUFS_BLOCK_USED;

        // Copy the modified free block list to disk.
        muDisk_write(fs->disk, MUFS_FREEBLOCKMAP_NUMBER, &(fs->freeBlocks));

        // Copy the modified inode to disk.
        muFS_internal_writeINode(fs, file->iNodeNumber, &(file->inode));
    }
    // Write the block.
    muDisk_write(fs->disk, file->inode.directBlocks[blockNum], buffer);

    // Return success.
    return 0;
}


int
muFS_deleteFile (MUFS* fs, uint16_t iNodeNum)
{
    // If inode number is invalid: set muerrno and return -1.
    if (iNodeNum >= MUFS_INODE_COUNT || iNodeNum < 0) {
        muerrno = ERR_MUFS_INVALID_INODE_NUM;
        return -1;
    }

    // If inode is currently open: set muerrno and return -1.
    if (fs->files[iNodeNum] != NULL) {
        muerrno = ERR_MUFS_FILE_IS_OPEN;
        return -1;
    }

    // Read requested inode.
    struct iNode inode;
    muFS_internal_readINode(fs, iNodeNum, &inode);

    // If inode is not in use: set muerrno and return -1.
    if (!inode.used) {
        muerrno = ERR_MUFS_INODE_NOT_USED;
        return -1;
    }

    // Mark every block this file was using as free.
    for (int i = 0; i < MUFS_NUM_DIRECT_BLOCKS; i++) {
        if (inode.directBlocks[i] != 0) {
            fs->freeBlocks.isUsed[inode.directBlocks[i]] = MUFS_BLOCK_AVAILABLE;
            inode.directBlocks[i] = 0;
        }
    }

    // Mark the inode itself as free.
    inode.used = 0;

    // Write the inode back to disk.
    muFS_internal_writeINode(fs, iNodeNum, &inode);

    // Write the free block list back to disk.
    muDisk_write(fs->disk, MUFS_FREEBLOCKMAP_NUMBER, &(fs->freeBlocks));

    // Return success.
    return 0;
}


void
muFS_format (MUDISK* disk)
{
    // Set the superblock.
    char buffer[MUDISK_BLOCK_SIZE];
    strncpy(buffer, MUFS_VERSION10, MUFS_IDENTIFIER_LENGTH);
    muDisk_write(disk, MUFS_SUPERBLOCK_NUMBER, &buffer);

    // Set the free block map.
    uint8_t buffer2[MUDISK_BLOCK_SIZE];
    memset(buffer2, 0, MUDISK_BLOCK_SIZE);
    for (unsigned int i = MUFS_SUPERBLOCK_NUMBER; i < MUFS_FIRSTDATABLOCK_NUMBER; i++) {
        buffer2[i] = 1;
    }
    muDisk_write(disk, MUFS_FREEBLOCKMAP_NUMBER, &buffer2);


    // Zero out all of the inodes.
    struct iNode buffer3[MUFS_INODES_PER_BLOCK];
    memset(buffer3, 0, MUDISK_BLOCK_SIZE);
    for (unsigned i = MUFS_FIRSTINODEBLOCK_NUMBER; i < MUFS_FIRSTDATABLOCK_NUMBER; i++) {
        muDisk_write(disk, i, &buffer3);
    }
}


uint16_t
muFS_getINodeNum (MUFILE* file)
{
    // Return the inode number associated with that file handle.
    return file->iNodeNumber;
}

