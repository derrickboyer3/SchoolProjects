// File: mufs.h
// Author: Chad Hogg
// Public interface of the Millersville University File System library.
// Part of handout for mustorage2 lab in CSCI380.

#ifndef MUFS_H
#define MUFS_H

#include <stdint.h>

#include "mudisk.h"

// The string that tells us a disk has been formatted with version 1.0 of MUFS.
#define MUFS_VERSION10 "mufs1.0"
// The length of the version string, including null terminator.
#define MUFS_IDENTIFIER_LENGTH 8
// The size of a single index node.
#define MUFS_INODE_SIZE 64
// The number of bytes reserved for OS metadata in each inode.
#define MUFS_INODE_RESERVED 15
// The number of index nodes.
#define MUFS_INODE_COUNT 256
// The number of inodes that fit into a block.
#define MUFS_INODES_PER_BLOCK (MUDISK_BLOCK_SIZE / MUFS_INODE_SIZE)
// The number of direct blocks in each index node.
#define MUFS_NUM_DIRECT_BLOCKS 12
// The block number of the superblock.
#define MUFS_SUPERBLOCK_NUMBER 0
// The block number of the free block map.
#define MUFS_FREEBLOCKMAP_NUMBER 1
// The block number of the first block containing index nodes.
#define MUFS_FIRSTINODEBLOCK_NUMBER 2
// The block number of the last block containing index nodes.
#define MUFS_FIRSTDATABLOCK_NUMBER 18
// The value in the free block list that indicates a block is in use.
#define MUFS_BLOCK_USED 1
// The value in the free block list that indicates a block is free.
#define MUFS_BLOCK_AVAILABLE 0
// The maximum size of a file (because we do not use indirect blocks).
#define MUFS_MAX_FILE_SIZE (MUFS_NUM_DIRECT_BLOCKS * MUDISK_BLOCK_SIZE)
// The value in an index node that indicates the index node is in use.
#define MUFS_INODE_USED 1
// The value in an index node that indicates the index node is free.
#define MUFS_INODE_AVAILABLE 0

//// Forward declarations of structures -- definitions only in source file.
struct muFS;
// A handle allowing code to interact with a loaded filesystem.
typedef struct muFS MUFS;
struct muFile;
// A handle allowing code to interact with an opened file.
typedef struct muFile MUFILE;



// Opens a filesystem that exists on a virtual disk.
// Parameters:
// - disk [in] A handle for the virtual disk on which the filesystem can be found.
// Returns:
// - A handle for the filesystem.
// Preconditions:
// - disk is a valid handle to a virtual disk that stores an MUFS filesystem.
// Errors:
// - Returns NULL and sets muerrno to ERR_MUFS_WRONG_VERSION if the virtual disk does not seem to store an MUFS filesystem.
MUFS*
muFS_open (MUDISK* disk);


// Releases resources used by a filesystem.
// Parameters:
// - fs [in] A handle for the filesystem that should be closed.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// Postconditions:
// - All resources used by the filesystem (but not the underlying virtual disk) have been released.  It should no longer be used.
void
muFS_close (MUFS* fs);


// Opens an existing file.
// Parameters:
// - fs [in] A handle for the filesystem within which the file exists.
// - iNodeNum [in] The number of the requested file's inode.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - iNodeNum is a currently used inode in that filesystem.
// Returns:
// - A handle to the opened file.  This MUFILE should be closed when no longer needed.
// Errors:
// - Returns NULL and sets muerrno to ERR_MUFS_INVALID_INODE_NUM if the inode number is out of range.
// - Returns NULL and sets muerrno to ERR_MUFS_INODE_NOT_USED if there is no file using that inode.
MUFILE*
muFS_openFile (MUFS* fs, uint16_t iNodeNum);


// Closes an open file.
// Parameters:
// - fs [in] A handle for the filesystem within which the file exists.
// - file [in] A handle for the file that should be closed.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - file is a valid handle to an open file from that filesystem.
// Postconditions:
// - This file handle is no longer valid and may not be used.
void
muFS_closeFile (MUFS* fs, MUFILE* file);


// Creates (and opens) a new file.
// Parameters:
// - fs [in] A handle for the filesystem within which the file should be created.
// - metadata [in] Whatever metadata the OS would like to store about the new file.
// Preconditions:
// - fs is a valid handle to an open filesystem with at least one unused inode.
// - metadata points to a block of MUFS_INODE_RESERVED bytes.
// Returns:
// - A handle for the opened file.  It should be closed when no longer needed.
// Postconditions:
// - A new file has been created.
// Errors:
// - Returns NULL, sets muerrno to ERR_MUFS_NO_AVAILABLE_INODES, and makes no changes to the filesystem if every inode is already in use.
MUFILE*
muFS_createFile (MUFS* fs, void* metadata);


// Reads the metadata about an open file.
// Parameters:
// - fs [in] A handle for the filesystem in which the file exists.
// - file [in] a handle for the file whose metadata is desired.
// - metadata [out] A location into which the metadata should be written.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - file is a valid handle to an open file in that filesystem.
// - metadata points to a block of MUFS_INODE_RESERVED bytes.
// Postconditions:
// - That metadata has been stored about the file.
void
muFS_readMetadata (MUFS* fs, MUFILE* file, void* metadata);


// Writes the metadata about an open file.
// Parameters:
// - fs [in] A handle for the filesystem in which the file exists.
// - file [in] A handle for the file whose metadata should be changed.
// - metadata [in] A pointer to the metadata that should be stored for that file.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - file is a valid handle to an open file in that filesystem.
// - metadata points to a block of MUFS_INODE_RESERVED bytes.
// Postconditions:
// - The data in metadata has been stored for the file.
void
muFS_writeMetadata (MUFS* fs, MUFILE* file, void* metadata);


// Reads one of the blocks of an open file.
// Parameters:
// - fs [in] A handle for the filesystem in which the file lives.
// - file [in] A handle for the requested file.
// - blockNum [in] Which block of the file is desired (0 = first, 1 = second, ...).
// - buffer [out] The location that should be filled with the file data.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - file is a valid handle to an open file handle from that filesystem.
// - 0 <= blockNum < MUFS_NUM_DIRECT_BLOCKS.
// - The blockNum'th block for this file has been allocated.
// - buffer points to a block of MUDISK_BLOCK_SIZE bytes.
// Postconditions:
// - The requested data has been copied into buffer.
// Returns:
// - 0 if successful, -1 on error.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUFS_INVALID_BLOCK_NUM if the block number is too large.
// - Returns -1 and sets muerrno to ERR_MUFS_READ_UNALLOCATED if the requested block has not been allocated.
int
muFS_readFileBlock (MUFS* fs, MUFILE* file, uint32_t blockNum, void* buffer);


// Writes one of the blocks of an open file.
// Parameters:
// - fs [in] A handle for the filesystem in which the file lives.
// - file [in] A handle for the file that should be written.
// - blockNum [in] Which block of the file should be written (0 = first, 1 = second, ...).
// - buffer [in] A pointer to the data that should be stored.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - file is a valid handle to an open file from that filesystem.
// - 0 <= blockNum < MUFS_NUM_DIRECT_BLOCKS.
// - buffer points to a block of MUDISK_BLOCK_SIZE bytes.
// Postconditions:
// - If the blockNum'th block for this file had not been allocated and a free block exists, it is allocated.
// - The data has been copied to the requested block.
// Returns:
// - 0 if successful, or -1 on error.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUFS_INVALID_BLOCK_NUM if the block number is too large.
// - Returns -1 and sets muerrno to ERR_MUFS_NO_AVAILABLE_BLOCKS if a new allocation would be needed and is impossible.
int
muFS_writeFileBlock (MUFS* fs, MUFILE* file, uint32_t blockNum, void* buffer);


// Frees up the inode and data blocks used by a file.
// Parameters:
// - fs [in] A handle for the filesystem in which the file lives.
// - iNodeNum [in] The number of the inode for the file that should be deleted.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - iNodeNum is the number of a used inode for a file that is not open.
// Postconditions:
// - The inode and any data blocks used by the file are no longer used.
// Returns:
// - 0 on success, or -1 on error.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUFS_INVALID_INODE_NUM if iNodeNum is invalid.
// - Returns -1 and sets muerrno to ERR_MUFS_INODE_NOT_USED if the specified inode is not in use.
// - Returns -1 and sets muerrno to ERR_MUFS_FILE_IS_OPEN if the file is currently open.
int
muFS_deleteFile (MUFS* fs, uint16_t iNodeNum);


// Formats a virtual disk, erasing any contents that it had.
// Parameters:
// - disk [in] A handle for the virtual disk that should be formatted.
// Preconditions:
// - disk is a valid handle to an open virtual disk.
// Postconditions:
// - The first block contains MUFS_VERSION10 and then zeroes.
// - The free block map says that [only] blocks MUFS_SUPERBLOCK_NUMBER up to but not including MUFS_FIRSTDATABLACK_NUMBER are used.
// - Each inode has all data zeroed out.
// - The data blocks have not been modified.
void
muFS_format (MUDISK* disk);


// Determines which inode is used for an open file.
// Parameters:
// - file [in] A handle for a file.
// Preconditions:
// - file is a valid handle to an open file.
// Returns:
// - The inode number used by that file.
uint16_t
muFS_getINodeNum (MUFILE* file);

#endif//MUFS_H