/*
 * File name: mush.c
 * Author: Derrick Boyer 380
 * Assignment: Lab 2; Writing your own shell part A
 */

/*Includes and Global Variables*/
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAX_INPUT 1024

/*Helper function header declarations*/
void removeWhiteSpace (char *prompt);

/*Functional Code*/

/*
 * Main method that implements the while loop pseudocode from class
 */
int
main ()
{
    // Infinite while loop that can only be exited with the specifying command prompt
    while (1) {
        // Create char array for input and print shell prompt allowing for input from the user
        char prompt[MAX_INPUT];
        printf("mush> ");
        // Flush the output buffer before getting the next command
        fflush(stdout);
        // Check to see if the input is NULL
        if (fgets(prompt, MAX_INPUT, stdin) == NULL) {
            printf("\n");
            break;
        }
        // Use strcspn to get rid of new line char at the end of the input
        prompt[strcspn(prompt, "\n")] = '\0';
        // Use helper function to get rid of the whitespace in the prompt
        removeWhiteSpace(prompt);
        // Check to see if the command is quit using the strcmp function
        if (strcmp(prompt, "quit") == 0) {
            break;
        }
        // If it is not quit then return "I dont know yet how to ____"
        if (strlen(prompt) > 0) {
            printf("I don't yet know how to %s\n", prompt);
        }
    }
    return 0;
}

/*
 * A helper function for removing the whitespace from the command prompt
 */
void
removeWhiteSpace (char *prompt) 
{
    // Create pointer variables for the beginning and the end of the input
    char *start = prompt;
    char *end = prompt + strlen(prompt) - 1;
    // Get rid of the leading whitespace by using the isspace function
    while (isspace(*start)) {
        start++;
    }
    // Get rid of all the trailing whitespace
    while (end > start && isspace(*end)) {
        *end-- = '\0';
    }
    // Move the rest of the characters up to the beginning of the string
    if (start != prompt) {
        while (*start) {
            *prompt++ = *start++;
        }
        *prompt = '\0';
    }
}