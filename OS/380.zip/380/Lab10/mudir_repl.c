// File: mudir_repl.c
// Author: Chad Hogg
// Program that experiments with the MU Directory Library.
// Part of the handout for mustorage3 lab in CSCI380.

#include "mudir.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define BUFFER_SIZE 4096

// Prints instructions for how to run the program.
void
printInstructions ();

int
main (int argc, char* argv[])
{
  // Confirm that we got a filename (and nothing else).
  if (argc != 2) {
    fprintf (stderr, "Usage: %s <filename>\n", argv[0]);
    exit (EXIT_FAILURE);
  }

  printInstructions ();
  char buffer[BUFFER_SIZE];

  // Open the disk.
  MUDISK* disk = muDisk_open (argv[1]);
  
  // Ensure that the disk was able to be opened.
  if (disk == NULL) {
    fprintf (stderr, "MUError: %d\n", muerrno);
    exit (EXIT_FAILURE);
  }

  // If desired, format disk.
  printf("Re-format disk [warning: destructive] (y/n): ");
  fgets (buffer, BUFFER_SIZE, stdin);
  if (strlen (buffer) > 0 && buffer[0] == 'y') {
    muFS_format (disk);
  }

  // Load the filesystem.
  MUFS* fs = muFS_open (disk);

  // Ensure that the filesystem was able to be loaded.
  if (fs == NULL) {
    fprintf(stderr, "MUError: %d\n", muerrno);
    exit (EXIT_FAILURE);
  }

  // Loop until the user decides to quit.
  while (true) {
    bool good = false;
    printf("mudir_repl> ");
    fgets (buffer, BUFFER_SIZE, stdin);
    char* first = strtok (buffer, " \n\t");
    char* second = (first == NULL ? NULL : strtok (NULL, " \n\t"));
    char* third = (second == NULL ? NULL : strtok (NULL, " \n\t"));
    char* fourth = (third == NULL ? NULL : strtok (NULL, " \n\t"));
    char* fifth = (fourth == NULL ? NULL : strtok (NULL, " \n\t"));
    if (first != NULL) {
      if (strcmp (first, "q") == 0 && second == NULL) {
        // quit
        if (second == NULL) {
          break;
        }
      }
      else if (strcmp (first, "m") == 0 && second != NULL && third == NULL) {
        // make
        char* end;
        int parNum = strtol (second, &end, 10);
        if (*end == '\0') {
          good = true;
          char metadata[MUFS_INODE_RESERVED];
          memset (metadata, 0, MUFS_INODE_RESERVED);
          MUFILE* file = muFS_createFile (fs, metadata);
          if (file == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          MUFILE* file2 = NULL;
          MUDIR* parent = NULL;
          if (parNum != -1) {
            file2 = muFS_openFile (fs, parNum);
            parent = muDir_openDir (fs, file2);

          }
          MUDIR* newDir = muDir_mkDir (fs, file, parent);
          muDir_closeDir (newDir);
          if (parNum != -1) {
            muDir_closeDir (parent);
            muFS_closeFile (fs, file2);
          }
          printf ("Created a new, empty directory using inode %d\n", muFS_getINodeNum (file));
          muFS_closeFile (fs, file);
        }
      }
      else if(strcmp (first, "l") == 0 && second != NULL && third != NULL && fourth != NULL && fifth == NULL) {
        // link a file into a directory
        char* end, * end2;
        int dirNum = strtol (second, &end, 10);
        int fileNum = strtol (third, &end2, 10);
        if (*end == '\0' && *end2 == '\0' && strlen (fourth) < MUDIR_MAX_NAME_LENGTH) {
          good = true;
          MUFILE* file = muFS_openFile (fs, dirNum);
          if (file == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          MUDIR* dir = muDir_openDir (fs, file);
          if (dir == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          int result = muDir_link (dir, fileNum, fourth);
          if (result != 0) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          muDir_closeDir (dir);
          muFS_closeFile (fs, file);
          printf ("Linked %d with name %s into the directory at %d.\n", fileNum, fourth, dirNum);
        }
      }
      else if(strcmp (first, "u") == 0 && second != NULL && third != NULL && fourth == NULL) {
        char* end;
        int iNodeNum = strtol (second, &end, 10);
        if (*end == '\0' && strlen (third) < MUDIR_MAX_NAME_LENGTH) {
          good = true;
          MUFILE* file = muFS_openFile (fs, iNodeNum);
          if (file == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          MUDIR * dir = muDir_openDir (fs, file);
          if (dir == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          int result = muDir_unlink (dir, third);
          if (result != 0) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          muDir_closeDir (dir);
          muFS_closeFile (fs, file);
          printf ("Unlinked %s from the directory at %d\n", third, iNodeNum);
        }
      }
      else if(strcmp (first, "s") == 0 && second != NULL && third == NULL) {
        char* end;
        int iNodeNum = strtol (second, &end, 10);
        if (*end == '\0') {
          good = true;
          MUFILE* file = muFS_openFile (fs, iNodeNum);
          if (file == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          MUDIR * dir = muDir_openDir (fs, file);
          if (dir == NULL) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          char names[MUDIR_ENTRIES_PER_DIR][MUDIR_MAX_NAME_LENGTH];
          muDir_getNameList (dir, names);
          for (int i = 0; i < MUDIR_ENTRIES_PER_DIR; ++i) {
            if (strlen (names[i]) > 0) {
              MUFILE* insideFile = muDir_findFile (fs, dir, names[i]);
              printf("%3d %s\n", muFS_getINodeNum (insideFile), names[i]);
              muFS_closeFile (fs, insideFile);
            }
          }
          muDir_closeDir (dir);
          muFS_closeFile (fs, file);
        }
      }
      if (!good)
      {
        printf ("This command was not understood -- no action has been taken.\n");
      }
    }
  }

  // Unload everything.
  muFS_close (fs);
  fs = NULL;
  muDisk_close (disk);
  disk = NULL;

  return EXIT_SUCCESS;
}

void
printInstructions ()
{
  printf ("Welcome to the MUDIR REPL.\n");
  printf ("Commands: \n");
  printf ("- q: Quits the program.\n");
  printf ("- m <#1>: Makes a new directory, whose parent is the directory with inode #1 (-1 for itself).\n");
  printf ("- l <#1> <#2> <#3>: Links, in the directory with inode #1, the file with inode #2, giving it the name #3.\n");
  printf ("- u <#1> <#2>: Unlinks, from within the directory with inode #1, the file with name #2.\n");
  printf ("- s <#1>: Shows the entries in the directory with inode #1.\n");
}

