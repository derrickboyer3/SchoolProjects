// File: mudir.c
// Author: Chad Hogg & Derrick Boyer
// Implementation of the Millersville University Directory Library
// Part of handout for mustorage3 lab in CSCI380.

#include "mudir.h"

#include <assert.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>


// An entry in a directory.
struct dirEntry
{
    // The number of the inode used by this entry.
    uint32_t iNodeNumber;
    // The name of this entry.
    char name[MUDIR_MAX_NAME_LENGTH];
};


// A disk block containing directory contents.
struct dirBlock
{
    char header[MUDIR_HEADER_LENGTH];
    struct dirEntry entries[MUDIR_ENTRIES_PER_DIR];
};


// A directory.
struct muDir
{
    MUFS* fs;
    MUFILE* file;
    struct dirBlock contents;
};


static_assert (sizeof (struct dirBlock) == MUDISK_BLOCK_SIZE, "Size of directory structure is wrong.");


MUFILE*
muDir_findFile (MUFS* fs, MUDIR* dir, const char fileName[MUDIR_MAX_NAME_LENGTH])
{
    // For each entry in directory:
    for (size_t i = 0; i < MUDIR_ENTRIES_PER_DIR; i++) {
        // If name matches: open and return file.
        if (strcmp(fileName, dir->contents.entries[i].name) == 0) {
            MUFILE* file = muFS_openFile(fs, dir->contents.entries[i].iNodeNumber);
            return file;
        }
    }
    // Didn't find it: set muerrno and return failure.
    muerrno = ERR_MUDIR_FILE_NOT_FOUND;
    return NULL;
}


MUDIR*
muDir_openDir (MUFS* fs, MUFILE* file)
{
    // Allocate space for directory on heap.
    MUDIR* dir = malloc(sizeof(MUDIR));

    // Read first (only) block of directory contents.
    muFS_readFileBlock(fs, file, 0, &(dir->contents));
    // If header does not match: set muerrno, free memory, return failure.
    if (strcmp(dir->contents.header, MUDIR_HEADER) != 0) {
        muerrno = ERR_MUDIR_NOT_DIRECTORY;
        free(dir);
        return NULL;
    }

    // Copy in fs and file, then return.
    dir->fs = fs;
    dir->file = file;
    return dir;
}


void
muDir_closeDir (MUDIR* dir)
{
    // Free memory used by dir.
    free(dir);
}


int
muDir_link (MUDIR* dir, uint32_t iNodeNumber, const char fileName[MUDIR_MAX_NAME_LENGTH])
{
    // For each entry in directory:
    size_t firstAvailable = -1;
    for(size_t i = 0; i < MUDIR_ENTRIES_PER_DIR; i++) {
        // If first one we've found that is available: remember it.
        if (strcmp(dir->contents.entries[i].name, "") == 0) {
            firstAvailable = i;
        }
        // If name matches: set muerrno and return failure.
        if (strcmp(dir->contents.entries[i].name, fileName) == 0) {
            muerrno = ERR_MUDIR_NAME_ALREADY_USED;
            return -1;
        }
    }
    // If no available entry found: set muerrno and return failure.
    if (firstAvailable == -1) {
        muerrno = ERR_MUDIR_FULL_DIR;
        return -1;
    }

    // Copy inodeNumber and name into available entry.
    dir->contents.entries[firstAvailable].iNodeNumber = iNodeNumber;
    strncpy(dir->contents.entries[firstAvailable].name, fileName, MUDIR_MAX_NAME_LENGTH);

    // Write directory contents back to disk.
    muFS_writeFileBlock(dir->fs, dir->file, 0, &(dir->contents));

    // Return success.
    return 0;
}


int
muDir_unlink (MUDIR* dir, const char fileName[MUDIR_MAX_NAME_LENGTH])
{
    // For each entry in directory:
    for (size_t i = 0; i < MUDIR_ENTRIES_PER_DIR; i++) {
        // If name matches: replace name with empty string, write directory contents to disk, return success.
        if (strcmp(fileName, dir->contents.entries[i].name) == 0) {
            strncpy(dir->contents.entries[i].name, "", MUDIR_MAX_NAME_LENGTH);
            muFS_writeFileBlock(dir->fs, dir->file, 0, &(dir->contents));
            return 0;
        }
    }
    // No such entry found: set muerrno and return failure.
    muerrno = ERR_MUDIR_FILE_NOT_FOUND;
    return -1;
}


MUDIR*
muDir_mkDir (MUFS* fs, MUFILE* file, MUDIR* parent)
{
    // Allocate space for directory on heap.
    MUDIR* dir = malloc(sizeof(MUDIR));
    // Set the filesystem and file for the directory.
    dir->fs = fs;
    dir->file = file;
    // Zero out the contents.
    for (size_t i = 0; i < MUDIR_ENTRIES_PER_DIR; i++) {
        memset(dir->contents.entries, 0, MUDIR_ENTRIES_PER_DIR * sizeof(struct dirEntry));
    }
    // Set the header to correct string.
    strncpy(dir->contents.header, MUDIR_HEADER, MUDIR_HEADER_LENGTH);
    // Link the "." entry to itself.
    char temp[MUDIR_MAX_NAME_LENGTH];
    temp[0] = '.';
    temp[1] = '\0';
    muDir_link(dir, muFS_getINodeNum(file), temp);
    // Link the ".." entry to parent, or to itself if no parent.
    temp[1] = '.';
    temp[2] = '\0';
    if (parent == NULL) {
        muDir_link(dir, muFS_getINodeNum(file), temp);
    }
    else {
        muDir_link(dir, muFS_getINodeNum(parent->file), temp);
    }
    // Write directory contents to disk.
    muFS_writeFileBlock(dir->fs, dir->file, 0, &(dir->contents));
    // Return the new directory.
    return dir;
}


void
muDir_getNameList (MUDIR* dir, char names[static MUDIR_ENTRIES_PER_DIR][MUDIR_MAX_NAME_LENGTH])
{
    // For each directory entry:
    for (size_t i = 0; i < MUDIR_ENTRIES_PER_DIR; i++) {
        // If name is non-empty, copy into matching location in array.
        if (strcmp("", dir->contents.entries[i].name) != 0) {
            memcpy(names[i], dir->contents.entries[i].name, MUDIR_MAX_NAME_LENGTH);
        }
        // Else, zero out matching location in array.
        else {
            strcpy(names[i], "");
        }
    }
}


MUFILE*
muDir_getFile (MUDIR* dir)
{
    // Return the directory.
    return dir->file;
}
