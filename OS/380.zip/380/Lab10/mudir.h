// File: mudir.h
// Author: Chad Hogg
// Public interface of the Millersville University Directory Library
// Part of handout for mustorage3 lab in CSCI380.

#ifndef MUDIR_H
#define MUDIR_H

#include "mufs.h"

#define MUDIR_MAX_NAME_LENGTH 28
#define MUDIR_HEADER "This file is a muDir directory."
#define MUDIR_HEADER_LENGTH 32
#define MUDIR_ENTRIES_PER_DIR 31

// Forward declaration.
struct muDir;
typedef struct muDir MUDIR;

// Opens a file based on its name.
// Parameters:
// - fs [in] A handle to the filesystem on which the file resides.
// - dir [in] A handle to a directory that contains the file.
// - fileName [in] The name of the file.
// Preconditions:
// - fs must be a valid filesystem handle, dir a valid directory handle.
// - That directory must contain a file with the specified name.
// Returns:
// - A handle to the requested file, or NULL.
// Errors:
// - Returns NULL and sets muerrno to ERR_MUDIR_FILE_NOT_FOUND if the directory does not contain a file with that name.
MUFILE*
muDir_findFile (MUFS* fs, MUDIR* dir, const char fileName[static MUDIR_MAX_NAME_LENGTH]);


// Opens a directory so that you can interact with it.
// Parameters:
// - fs [in] A handle to the filesystem in which the directory exists.
// - file [in] A handle to the file that stores the directory information.
// Preconditions:
// - fs must be a valid filesystem handle, file a valid file handle.
// - The file must be structured as a directory.
// Returns:
// - A handle allowing thils file to be treated as a directory.  This must be closed when no longer needed.
// Errors:
// - Returns NULL and sets muerrno to ERR_MUDIR_NOT_DIRECTORY if the file does not appear to be a directory.
MUDIR*
muDir_openDir (MUFS* fs, MUFILE* file);


// Closes a directory, releasing resources used by it.
// Parameters:
// - dir [in] A handle to the directory to be closed.
// Preconditions:
// - dir is a valid handle to a directory.
// Postconditions:
// - The resources used by dir (but not the underlying file) have been released.  It may no longer be used.
void
muDir_closeDir (MUDIR* dir);


// Links a file into a directory.
// Parameters:
// - dir [in] A handle to the directory into which we want to link.
// - iNodeNumber [in] The inode number of the file that should be linked.
// - fileName [in] The name that should be given to the file being linked.
// Preconditions:
// - dir is a valid handle to a directory.
// - The directory is not full.
// - The directory does not already contain a file with that name.
// Returns:
// - 0 on success or -1 for failure.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUDIR_NAME_ALREADY_USED if the directory contains a file with that name.
// - Returns -1 and sets muerrno to ERR_MUDIR_FULL_DIR if there is no available space in the directory.
int
muDir_link (MUDIR* dir, uint32_t iNodeNumber, const char fileName[MUDIR_MAX_NAME_LENGTH]);


// Unlinks a file from a directory.
// Parameters:
// - dir [in] A handle to the directory from which a file should be unlinked.
// - fileName [in] The name of the file that should be unlinked.
// Preconditions:
// - dir is a valid handle to a directory that contains the filename.
// Returns:
// - 0 on success or -1 for failure.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUDIR_FILE_NOT_FOUND if there is no file in the directory by that name.
int
muDir_unlink (MUDIR* dir, const char fileName[MUDIR_MAX_NAME_LENGTH]);


// Converts a file to a directory.
// Parameters:
// - fs [in] A handle to the filesystem in which the file resides.
// - file [in] A handle to the file that should store the directory.
// - parent [in] A handle to the parent of the new directory, or NULL for the root directory.
// Preconditions:
// - fs is a valid handle to an open filesystem.
// - file is a valid handle to an open file from that filesystem.
// - parent is a valid handle to a directory in that filesystem, or NULL.
// Returns:
// - A handle to a new directory in that file.
MUDIR*
muDir_mkDir (MUFS* fs, MUFILE* file, MUDIR* parent);


// Gets the names of all files in a directory.
// Parameters:
// - dir [in] The directory we want to list.
// - names [out] An array to fill up with names
void
muDir_getNameList (MUDIR* dir, char names[static MUDIR_ENTRIES_PER_DIR][MUDIR_MAX_NAME_LENGTH]);


// Gets the file that stores a directory.
// Parameters:
// - dir [in] A handle for the directory whose file we want to access.
// Returns:
// - A handle to that file.  You did not open it, and should not close it.
MUFILE*
muDir_getFile (MUDIR* dir);

#endif//MUDIR_H