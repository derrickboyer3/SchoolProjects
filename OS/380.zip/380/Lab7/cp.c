/*
 * Filename: cp.c
 * Author: Derrick Boyer
 * Last Updated: 17 March 2024
 * Description: This program implements a simple cp command with page sharing instead of 
 * using buffers to copy data over.
 */

/*Includes*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>


/*Functional Code*/
int
main (int argc, char* argv[]) {
    // Check argument count
    if (argc != 3) {
        printf("Wrong arg count; Should be 3 (\"cp <filesource> <filedest>\")\n");
        exit(1);
    }

    // Open source file
    int srcFD = open(argv[1], O_RDONLY);
    if (srcFD == -1) {
        printf("Error opening source file.\n");
        exit(1);
    }

    // Open destination file
    int destFD = open(argv[2], O_RDWR);
    if (srcFD == -1) {
        printf("Error opening source file.\n");
        exit(1);
    }

    // Get size of source file
    struct stat srcInfo;
    if(fstat(srcFD, &srcInfo) == -1) {
        printf("Error using fstat on source df.\n");
        exit(1);
    }

    // Truncate size of destination file
    if (ftruncate(destFD, srcInfo.st_size) == -1) {
        printf("Error truncating destination file.\n");
        exit(1);
    }

    // Create map for source file
    void* srcMap = mmap(NULL, srcInfo.st_size, PROT_READ, MAP_PRIVATE, srcFD, 0);
    if (srcMap == MAP_FAILED) {
        printf("Error using mmap on source file.\n");
    } 

    // Create map for destination file
    void* destMap = mmap(NULL, srcInfo.st_size, PROT_WRITE, MAP_SHARED, destFD, 0);
    if (destMap == MAP_FAILED) {
        printf("Error using mmap on dest file.\n");
    } 

    // Copy data from source to destination
    memcpy(destMap, srcMap, srcInfo.st_size);

    // Unmap source and destination files
    if (munmap(srcMap, srcInfo.st_size) == -1) {
        printf("Error using munmap on source file.\n");
    }
    if (munmap(destMap, srcInfo.st_size) == -1) {
        printf("Error using munmap on destination file");
    }

    // Close source and destination files
    if (close(srcFD) == -1) {
        printf("Error closing source file");
    }
    if (close(destFD) == -1) {
        printf("Error closing destination file");
    }

    printf("File copied successfully.\n");

    return 0;
}