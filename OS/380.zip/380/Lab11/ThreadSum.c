/*
 * ThreadSum.c
 * Author: Derrick Boyer
 * Compute the sum of an array of random numbers in the range [0,4] using threads to do so concurrently
 */

// Includes
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

// Global variables
int *A;
int N;
int p;
int sum = 0;

// Function prototypes
void *thread_sum(void *arg);

int main() {
    // User input
    printf("p ==> ");
    scanf("%d", &p);
    printf("N ==> ");
    scanf("%d", &N);

    // Allocate space for array
    A = malloc(N * sizeof(int));

    // Fill the array with random integers [0,4]
    for (int i = 0; i < N; i++) {
        // Mod by 5 to get a number within the specified range
        A[i] = rand() % 5;
    }

    // Array for thread IDs
    pthread_t threads[p];

    // Create threads
    for (long i = 0; i < p; i++) {
        pthread_create(&threads[i], NULL, thread_sum, (void *)i);
    }

    // Join threads and add up sums
    for (int i = 0; i < p; i++) {
        void *localSum;
        pthread_join(threads[i], &localSum);
        sum += (long)localSum;
    }

    // Calculate the serial sum
    int serialSum = 0;
    for (int i = 0; i < N; i ++) {
        serialSum += A[i];
    }

    // Print results and clean up
    printf("\nParallel sum: %d\nSerial Sum: %d\n", sum, serialSum);
    free(A);
    return 0;
}

// Thread function to compute local sum
void *thread_sum(void *arg) {
    // Create indices for computation using the ID
    long id = (long)arg;
    int beginning_index = (N / p) * id;
    int end_index = (N / p) * (id + 1);
    long localSum = 0;

    // Compute sum
    for (int i = beginning_index; i < end_index; i++) {
        localSum += A[i];
    }

    return (void *)localSum;
}
