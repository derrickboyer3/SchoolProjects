/*
 * Filename: Redir.c
 * Author: Derrick Boyer
 * Class: CSCI 380 S24
 * Description: Write a program that carries out the functions from the following shell script:
 * date | tr '\n' '\t\t' >> userlog.txt ; ps -Ao user | tail -n +2 | sort | uniq | wc -l >> userlog.txt
 */

/*Includes*/
#include <fcntl.h> // for open()
#include <unistd.h> // for dup2(), pipe(), and close()
#include "musys.h" // for Fork(), Wait()/Waitpid(), and Execvpe()
#include "musys.c"
#include <stdio.h>
#include <stdlib.h>


/*Functional Code*/

int
main() {
    // Open the log file and do error checking
    int logFile = open("userlog.txt", O_APPEND | O_WRONLY | O_CREAT, 0644);
    if (logFile == -1) {
        printf("ERROR opening log file.");
        exit(EXIT_FAILURE);
    }

    // Code for date | tr '\n' '\t\t' >> userlog.txt
    // Create a pipe for the first child
    int pipe1[2];
    if (pipe(pipe1) == -1) {
        perror("Pipe failed");
        exit(EXIT_FAILURE);
    }

    // Fork first child to run date command
    pid_t pid = Fork();
    if (pid == 0) {
        // Redirect stdout to pipe1
        dup2(pipe1[1], STDOUT_FILENO);
        close(pipe1[0]); // Close read end of pipe1

        // Execute date command
        char *args[] = {"date", NULL};
        Execvp(args[0], args);
    }
    else {
        // Close write end of pipe1 in parent
        close(pipe1[1]);

        // Wait for child to finish
        int status;
        Waitpid(pid, &status, 0);

        // Fork second child for tr command
        pid = Fork();
        if (pid == 0) {
            // Redirect stdin from pipe1
            dup2(pipe1[0], STDIN_FILENO);
            close(pipe1[0]); // Close read end of pipe1

            // Redirect stdout to log file
            dup2(logFile, STDOUT_FILENO);

            // Execute tr command
            char *args[] = {"tr", "\\n", "\\t\\t", NULL};
            Execvp(args[0], args);
        }
        else {
            // Close pipe1 completely
            close(pipe1[0]);
            close(pipe1[1]);

            // Wait for second child to finish
            Waitpid(pid, &status, 0);
        }
    }
    
    // Code for ps -Ao user | tail -n +2 | sort | uniq | wc -l >> userlog.txt
    // Create a pipe for the 3rd child
    int pipe2[2];
    if (pipe(pipe2) == -1) {
        perror("Pipe failed");
        exit(EXIT_FAILURE);
    }

    // Fork 3rd child and run ps command
    pid = Fork();
    if (pid == 0) {
        // Redirect stdout to pipe2
        dup2(pipe2[1], STDOUT_FILENO);
        close(pipe2[0]); // Close read end of pipe2

        // Execute date command
        char *args[] = {"ps", "-Ao", "user", NULL};
        Execvp(args[0], args);
    }
    else {
        // Create third pipe
        int pipe3[2];
        if (pipe(pipe3) == -1) {
            perror("Pipe failed");
            exit(EXIT_FAILURE);
        }
        
        // Create fourth pipe
        int pipe4[2];
        if (pipe(pipe4) == -1) {
            perror("Pipe failed");
            exit(EXIT_FAILURE);
        }

        // Create fifth pipe
        int pipe5[2];
        if (pipe(pipe5) == -1) {
            perror("Pipe failed");
            exit(EXIT_FAILURE);
        }

        // Close write end of pipe2 in parent
        close(pipe2[1]);

        // Wait for 3rd child to finish
        int status;
        Waitpid(pid, &status, 0);

        // Fork 4th child for tail command
        pid = Fork();
        if (pid == 0) {
            // Redirect stdin from pipe2
            dup2(pipe2[0], STDIN_FILENO);
            close(pipe2[0]); // Close read end of pipe2

            // Redirect stdout to pipe3
            dup2(pipe3[1], STDOUT_FILENO);
            close(pipe3[0]); // Close read end of pipe3

            // Execute tail command
            char *args[] = {"tail", "-n", "+2", NULL};
            Execvp(args[0], args);
        }
        else {
            // Close pipe1 and pipe2
            close(pipe1[0]);
            close(pipe1[1]);
            close(pipe2[0]);
            close(pipe2[1]);

            // Wait for 4th child to finish
            Waitpid(pid, &status, 0);
            
            // Fork 5th child
            pid = Fork();
            if (pid == 0) {
                // Close write end of pipe3
                close(pipe3[1]);

                // Redirect stdin from pipe3
                dup2(pipe3[0], STDIN_FILENO);
                close(pipe3[0]); // Close read end of pipe3

                // Redirect STDOUT to pipe4
                dup2(pipe4[1], STDOUT_FILENO);

                // Execute sort command
                char *args[] = {"sort", NULL};
                Execvp(args[0], args);

            }
            else {
                // Close pipe1, pipe2, and pipe3
                close(pipe1[0]);
                close(pipe1[1]);
                close(pipe2[0]);
                close(pipe3[0]);
                close(pipe3[1]);

                // Wait for fifth child to finish
                Waitpid(pid, &status, 0);

                // Fork 6th child for uniq command
                pid = Fork();
                if (pid == 0) {
                    // Close write end of pipe4
                    close(pipe4[1]);

                    // Redirect stdin from pipe4
                    dup2(pipe4[0], STDIN_FILENO);
                    close(pipe4[0]); // Close read end of pipe4

                    // Redirect STDOUT to pipe5
                    dup2(pipe5[1], STDOUT_FILENO);

                    // Execute uniq command
                    char *args[] = {"uniq", NULL};
                    Execvp(args[0], args);
                }
                else {
                    // Close pipe1, pipe2, pipe3, and pipe4
                    close(pipe1[0]);
                    close(pipe1[1]);
                    close(pipe2[0]);
                    close(pipe3[0]);
                    close(pipe3[1]);
                    close(pipe4[0]);
                    close(pipe4[1]);

                    // Wait for 6th child to finish
                    Waitpid(pid, &status, 0);

                    // Fork 7th child for wc command
                    pid = Fork();
                    if (pid == 0) {
                        // Close write end of pipe5
                        close(pipe5[1]);

                        // Redirect stdin from pipe4
                        dup2(pipe5[0], STDIN_FILENO);
                        close(pipe5[0]); // Close read end of pipe4

                        // Redirect STDOUT to logFile
                        dup2(logFile, STDOUT_FILENO);

                        // Execute wc command
                        char *args[] = {"wc", "-l", NULL};
                        Execvp(args[0], args);
                    }
                    else {
                        // Close all pipes
                        close(pipe1[0]);
                        close(pipe1[1]);
                        close(pipe2[0]);
                        close(pipe3[0]);
                        close(pipe3[1]);
                        close(pipe4[0]);
                        close(pipe4[1]);
                        close(pipe5[0]);
                        close(pipe5[1]);

                        // Wait for 7th child to finish
                        Waitpid(pid, &status, 0);
                    }
                }
            }
        }
    }
    

    // Close log file
    close(logFile);
    return 0;
}