// File: musys.h
// Author: Chad Hogg
// Prototypes of functions that wrap system calls up with error checking.

#include <unistd.h>
#include <signal.h>

//// Basic functions for printing that are async-signal-safe. ////

void
safePrintString (const char* s);

void
safePrintInt (int i);

//// Wrappers around system calls that print an error message and exit on failure. ////

pid_t
Fork ();

void
Execvp (char* file, char* const argv[]);

pid_t
Waitpid (pid_t pid, int* wstatus, int options);

// We do this because the signal() system call isn't fully portable.
typedef void (*mu_sighandler_t) (int);
mu_sighandler_t
Signal (int signum, mu_sighandler_t handler);

ssize_t
Write (int fd, const void* buf, size_t count);

int
Sigemptyset (sigset_t* set);

int
Sigfillset (sigset_t* set);

int
Sigaddset (sigset_t* set, int signum);

int
Sigdelset (sigset_t* set, int signum);

int
Sigprocmask (int how, const sigset_t* set, sigset_t* oldset);

int
Sigsuspend (const sigset_t* mask);

int
Kill (pid_t pid, int sig);

pid_t
Getpid (void);

pid_t
Getppid (void);

int
Setpgid (pid_t pid, pid_t pgid);

int
Setpgrp (void);
