/*
 * File name: mushc.c
 * Author: Derrick Boyer 380
 * Assignment: Lab 3; Writing your own shell part C
 */

/*Includes and Global Variables*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <ctype.h>
#include "musys.h"
#include <signal.h>

#define MAX_INPUT_LENGTH 1024
#define MAX_TOKENS 128
volatile pid_t g_foregroundPid = 0; // I created a global variable to help of the foreground job easier

/*Helper function header declarations*/
// Didn't need to make the wrapper functions because they were included in the musys.h file
void removeWhiteSpace(char *prompt);
void executeCommand(char *tokens[], int background);
void reapZombies(int signal);


 /*Functional Code*/

/*
 * Main method that implements the while loop pseudocode from class
 */
int main() {
    // Array for the input prompt
    char prompt[MAX_INPUT_LENGTH];
    // Infinite while loop
    while (1) {
        // Print prompt and flush the output buffer
        printf("mushc> ");
        fflush(stdout);
        // Check to see if the input is NULL and if so print a new line and prompt
        fgets(prompt, MAX_INPUT_LENGTH, stdin);
        // Use strcspn to get rid of new line char at the end of the input
        prompt[strcspn(prompt, "\n")] = '\0';
        // Use helper function to get rid of the whitespace in the prompt
        removeWhiteSpace(prompt);
        // Check for quit command
        if (strcmp(prompt, "quit") == 0) {
            break;
        }
        // Create array for all tokens
        char *tokens[MAX_TOKENS];
        // Go through each token in the input and add it to the array of tokens
        char *token = strtok(prompt, " \t");
        int token_count = 0;
        while (token != NULL && token_count < MAX_TOKENS - 1) {
            tokens[token_count++] = token;
            token = strtok(NULL, " \t");
        }
        // Add a NULL character at the end of the tokens in the array so we know when the tokens end
        tokens[token_count] = NULL;
        // Check for background job by looking for '&' at the end
        int background = 0;
        if (token_count > 0 && strcmp(tokens[token_count - 1], "&") == 0) {
            background = 1;
            // Replace '&' with NULL
            tokens[token_count - 1] = NULL; 
        }
        // Execute command using helper function if it is not null
        if (tokens[0] != NULL) {
            executeCommand(tokens, background);
        }
    }
    return 0;
}

/*
 * A helper function for removing the whitespace from the command prompt
 */
void removeWhiteSpace(char *prompt) {
    // Create pointer variables for the beginning and the end of the input
    char *start = prompt;
    char *end = prompt + strlen(prompt) - 1;
    // Get rid of the leading whitespace by using the isspace function
    while (isspace(*start)) {
        start++;
    }
    // Get rid of all the trailing whitespace
    while (end > start && isspace(*end)) {
        *end-- = '\0';
    }
    // Move the rest of the characters up to the beginning of the string
    if (start != prompt) {
        while (*start) {
            *prompt++ = *start++;
        }
        *prompt = '\0';
    }
}


void executeCommand(char *tokens[], int background) {
    // Block SIGCHLD signals
    sigset_t mask, prev;
    Sigemptyset(&mask);
    Sigaddset(&mask, SIGCHLD);
    Sigprocmask(SIG_BLOCK, &mask, &prev);
    // Install signal handler for SIGCHLD
    Signal(SIGCHLD, reapZombies);
    // Fork to create child and parent processes
    pid_t pid = Fork();
    // Check for and handle child process
    if (pid == 0) {
        Execvp(tokens[0], tokens);
    }
    // Handle parent process 
    else {
        // Check for and handle foreground process by waiting for child process to finish
        if (!background) {
            // For foreground jobs, wait for the child process to finish
            g_foregroundPid = pid;
            while (g_foregroundPid != 0) {
                Sigsuspend(&prev);
            }
            // Reset g_foregroundPid after the process finishes
            g_foregroundPid = 0;
        // Handle background job by printing the process ID and the command given
        // Background jobs do not have to wait for child to finish
        } else {
            // Print a message for background process
            printf("(%d) ", pid);
            for (int i = 0; tokens[i] != NULL; i++) {
                printf("%s ", tokens[i]);
            }
            printf("&\n");
        }
    }
    // Unblock SIGCHLD signals
    Sigprocmask(SIG_SETMASK, &prev, NULL);
}

/*
 * Helper function for reaping the child processes when the signal is sent
 */
void reapZombies(int signal) {
    int status;
    pid_t pid;
    // Save old errno
    int olderrno = errno;
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        // Use async-signal-safe functions from header file for printing out when the child is reaped
        safePrintString("Reaped ");
        safePrintInt(pid);
        safePrintString("\n");
        if (pid == g_foregroundPid) {
            // Reset foreground pid
            g_foregroundPid = 0;
        }
    }
    // Restore old errno
    errno = olderrno;
}