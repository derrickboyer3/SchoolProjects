/* 
 * Code for basic C skills diagnostic.
 * Developed for courses 15-213/18-213/15-513 by R. E. Bryant, 2017
 */

/*
 * This program implements a queue supporting both FIFO and LIFO
 * operations.
 *
 * It uses a singly-linked list to represent the set of queue elements
 */

#include <stdlib.h>
#include <stdio.h>

#include "harness.h"
#include "queue.h"

/*Create empty queue.
  Return NULL if could not allocate space.
*/
queue_t *q_new()
{
  //create new queue_t by allocating space
  queue_t *q =  malloc(sizeof(queue_t));

  //if space could not be allocated return NULL
  if (q == NULL) {
    return NULL;
  }

  //set fields and return q
  q->head = NULL;
  q->tail = NULL;
  q->size = 0;
  return q;
}

/* Free all storage used by queue */
void q_free(queue_t *q)
{
    //check for null queue
    if (q == NULL) {
        return;
    }

    //create a temp variable that points to q's head
    //free q
    list_ele_t *temp = q->head;
    free(q);

    //loop through and free all data in q
    while (temp != NULL) {
      list_ele_t *temp_copy = temp;
      temp = temp->next;
      free(temp_copy);
    }
}

/*Attempt to insert element at head of queue.
  Return true if successful.
  Return false if q is NULL or could not allocate space.
 */
bool q_insert_head(queue_t *q, int v)
{
    list_ele_t *newh;
    //if q is NULL return false
    if (q == NULL) {
      return false;
    }

    //allocate space for the new head
    newh = malloc(sizeof(list_ele_t));

    //if you couldn't allocate space then return false
    if (newh == NULL) {
      return false;
    }

    //store data and update fields
    newh->value = v;
    newh->next = q->head;
    q->head = newh;
    q->size++;
    if (q->size == 1) {
      q->tail = newh;
    }
    return true;
}


/*Attempt to insert element at tail of queue.
  Return true if successful.
  Return false if q is NULL or could not allocate space.
 */
bool q_insert_tail(queue_t *q, int v)
{
    list_ele_t *newt;
    //if q is NULL return false
    if (q == NULL) {
      return false;
    }

    //allocate space for new tail
    newt = malloc(sizeof(list_ele_t));

    //if you could not allocate space for the new tail return false
    if (newt == NULL) {
      return false;
    }

    //update fields and check special case (size == 0 and size == 1)
    newt->value = v;
    newt->next = NULL;
    if (q->tail != NULL) {
      q->tail->next = newt;
    }
    q->tail = newt;
    q->size++;
    if (q->size == 1) {
      q->head = newt;
    }
    return true;
}

/*Attempt to remove element from head of queue.
  Return true if successful.
  Return false if queue is NULL or empty.
  If vp non-NULL and element removed, store removed value at *vp.
  Any unused storage should be freed
*/
bool q_remove_head(queue_t *q, int *vp)
{
    //check for NULL or empty queue
    if (q == NULL || q->head == NULL) {
      return false;
    }

    //create a pointer to the old head
    list_ele_t *old = q->head;

    //check for vp == NULL
    //if not store the old value at vp
    if (vp != NULL) {
      *vp = old->value;
    }

    //update fields to ignore the old head and free the old head
    q->head = old->next;
    free (old);
    q->size--;
    return true;
}

/*Return number of elements in queue.
  Return 0 if q is NULL or empty
 */
int q_size(queue_t *q)
{
    //return the size of the queue
    return q->size;
}

/*
  Reverse elements in queue.

  Your implementation must not allocate or free any elements (e.g., by
  calling q_insert_head or q_remove_head).  Instead, it should modify
  the pointers in the existing data structure.
 */
void q_reverse(queue_t *q)
{
  //check for null or empty queue
  if (q == NULL || q->head == NULL) {
    return;
  }

  //create temp variables for new queue
  list_ele_t *p = q->head;
  list_ele_t *prev = NULL;
  list_ele_t *next = p->next;

  //loop through and copy elements into new queue
  while (p->next != NULL) {
    p->next = prev;
    prev = p;
    p = next;
    next = p->next;
  }

  //update new queue's fields and set q to point at new queue's head
  p->next = prev;
  q->tail = q->head;
  q->head = p;
}


