/*
 * File name: mushb.c
 * Author: Derrick Boyer 380
 * Assignment: Lab 3; Writing your own shell part B
 */

/*Includes and Global Variables*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <ctype.h>

#define MAX_INPUT_LENGTH 1024
#define MAX_TOKENS 128

/*Helper function header declarations*/
 
// Wrapper functions for system calls to hide error handling
void removeWhiteSpace (char *prompt);
pid_t Fork ();
int Execvp (char* file, char* const argv[]);
pid_t Waitpid (pid_t pid, int* wstatus, int options);
void executeCommand(char *tokens[], int background);


 /*Functional Code*/

/*
 * Main method that implements the while loop pseudocode from class
 */
int
main() {
    // Array for the input prompt
    char prompt[MAX_INPUT_LENGTH];
    // Infinite while loop
    while (1) {
        // Print prompt and flush the output buffer
        printf("mushb> ");
        fflush(stdout);
        // Check to see if the input is NULL and if so print a new line and prompt
        if (fgets(prompt, MAX_INPUT_LENGTH, stdin) == NULL) {
            // Handle end of input
            printf("\n");
            break;
        }
        // Use strcspn to get rid of new line char at the end of the input
        prompt[strcspn(prompt, "\n")] = '\0';
        // Use helper function to get rid of the whitespace in the prompt
        removeWhiteSpace(prompt);
        // Check for quit command
        if (strcmp(prompt, "quit") == 0) {
            break;
        }
        // Create array for all tokens
        char *tokens[MAX_TOKENS];
        // Go through each token in the input and add it to the array of tokens
        char *token = strtok(prompt, " \t");
        int token_count = 0;
        while (token != NULL && token_count < MAX_TOKENS - 1) {
            tokens[token_count++] = token;
            token = strtok(NULL, " \t");
        }
        // Add a NULL character at the end of the tokens in the array so we know when the tokens end
        tokens[token_count] = NULL;
        // Check for background job by looking for '&' at the end
        int background = 0;
        if (token_count > 0 && strcmp(tokens[token_count - 1], "&") == 0) {
            background = 1;
            // Replace '&' with NULL
            tokens[token_count - 1] = NULL; 
        }
        // Execute command using helper function
        executeCommand(tokens, background);
    }
    return 0;
}

/*HELPER FUNCTIONS TO HANDLE ERRORS FOR FORK, EXECVPE, AND WAITPID*/

/*
 * Fork helper function to do error handling if fork does not work
 */
pid_t
Fork ()
{
    // Fork the processes and create a child
    pid_t result = fork ();
    // If the fork was unsuccessful the pid_t will be negative
    // If so print an error message
    if (result < 0) {
        printf ("fork error: %s", strerror (errno));
        exit (EXIT_FAILURE);
    }
    // Return pid_t from successful fork
    return result;
}

/*
 * Execvpe helper function to do error handling if execvpe does not work
 */
int
Execvp (char* file, char* const argv[])
{
    // If execvpe did not work print out an error message and exit the program
    int result = execvp (file, argv);
    printf ("exec error: %s", strerror (errno));
    exit (EXIT_FAILURE);
}

/*
 * Waitpid helper function to do error handling if waitpid does not work
 */
pid_t
Waitpid (pid_t pid, int* wstatus, int options)
{
    // If the waitpid call was -1 then it did not work
    // If so print out an error message to the user and exit the program
    pid_t result = waitpid (pid, wstatus, options);
    if (result == -1) {
        printf ("waitpid error: %s", strerror (errno));
        exit (EXIT_FAILURE);
    }
}

/*
 * A helper function for removing the whitespace from the command prompt
 */
void
removeWhiteSpace (char *prompt) 
{
    // Create pointer variables for the beginning and the end of the input
    char *start = prompt;
    char *end = prompt + strlen(prompt) - 1;
    // Get rid of the leading whitespace by using the isspace function
    while (isspace(*start)) {
        start++;
    }
    // Get rid of all the trailing whitespace
    while (end > start && isspace(*end)) {
        *end-- = '\0';
    }
    // Move the rest of the characters up to the beginning of the string
    if (start != prompt) {
        while (*start) {
            *prompt++ = *start++;
        }
        *prompt = '\0';
    }
}


/*
 * Helper function to run the command given
 */
void executeCommand(char *tokens[], int background) {
    // Fork to create child and parent processes
    pid_t pid = Fork();
    // Check for and handle child process
    if (pid == 0) {
        Execvp(tokens[0], tokens);
    } 
    // Handle parent process
    else {
        // Check for and handle foreground process by waiting for child process to finish
        if (!background) {
            int status;
            Waitpid(pid, &status, 0);
        } 
        // Handle background job by printing the process ID and the command given
        // Background jobs do not have to wait for child to finish
        else {
            printf("(%d) %s\n", pid, tokens[0]);
        }
    }
}

