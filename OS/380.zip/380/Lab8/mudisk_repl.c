// File: mudisk_repl.c
// Author: Chad Hogg
// Program that experiments with the MU Virtual Disk library.
// Part of the handout for mustorage1 lab in CSCI380.

#include "mudisk.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define BUFFER_SIZE 4096

// Prints instructions for how to run the program.
void
printInstructions ();

int
main (int argc, char* argv[])
{
  // Confirm that we got a filename (and nothing else).
  if (argc != 2)
  {
    fprintf (stderr, "Usage: %s <filename>\n", argv[0]);
    exit (EXIT_FAILURE);
  }

  printInstructions ();

  // Open the disk.
  MUDISK* disk = muDisk_open (argv[1]);

  // Ensure that the disk was able to be opened.
  if (disk == NULL) {
    fprintf (stderr, "MUError: %d\n", muerrno);
    exit (EXIT_FAILURE);
  }

  // Loop until the user decides to quit.
  char buffer[BUFFER_SIZE];
  while (true)
  {
    bool good = false;
    printf("mudisk_repl> ");
    fgets (buffer, BUFFER_SIZE, stdin);
    buffer[strcspn (buffer, "\n")] = '\0';
    if (strlen (buffer) > 0)
    {
      if (strcmp (buffer, "q") == 0)
      {
        break;
      }
      else if(buffer[0] == 'r' && strlen (buffer) >= 3 && buffer[1] == ' ')
      {
        char* end;
        int blkNum = strtol (buffer + 2, &end, 10);
        if (*end == '\0' && end != buffer + 2)
        {
          good = true;
          char buffer[MUDISK_BLOCK_SIZE + 1];
          if (muDisk_read (disk, blkNum, buffer) == -1) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
          buffer[MUDISK_BLOCK_SIZE] = '\0';
          printf("%s\n", buffer);
        }
      }
      else if(buffer[0] == 'w' && strlen (buffer) >= 5 && buffer[1] == ' ')
      {
        char* end;
        int blkNum = strtol (buffer + 2, &end, 10);
        if (*end == ' ' && end != buffer + 2 && strlen (end) > 1)
        {
          good = true;
          char buffer[MUDISK_BLOCK_SIZE];
          char* mover = end + 1;
          for (int index = 0; index < MUDISK_BLOCK_SIZE; ++index)
          {
            if (*mover == '\0')
            {
              mover = end + 1;
            }
            buffer[index] = *mover;
            ++mover;
          }
          if (muDisk_write (disk, blkNum, buffer) == -1) {
            fprintf (stderr, "MUError: %d\n", muerrno);
            return EXIT_FAILURE;
          }
        }
      }
      if (!good)
      {
        printf ("This command was not understood -- no action has been taken.\n");
      }
    }
  }

  // Close the disk.
  muDisk_close (disk);
  disk = NULL;

  return EXIT_SUCCESS;
}

void
printInstructions ()
{
  printf ("Welcome to the MUDisk REPL.\n");
  printf ("Commands: \n");
  printf ("- q: Quits the program.\n");
  printf ("- r <#>: Reads block number # and dumps to stdout.\n");
  printf ("- w <#> <pattern>: Writes pattern to block number #, tiling as necessary.\n");
}