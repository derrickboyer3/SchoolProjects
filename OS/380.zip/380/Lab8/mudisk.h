// File: mudisk.h
// Author: Chad Hogg
// Public interface of the Millersville University Virtual Disk library.
// Part of handout for mustorage1 lab in CSCI380.

#ifndef MUDISK_H
#define MUDISK_H

#include "muerrno.h"

#include <stdint.h>

// The number of bytes in a block.
#define MUDISK_BLOCK_SIZE 1024
// The number of blocks on the disk.
#define MUDISK_BLOCK_COUNT 1024
// The maximum length of a file path.
#define MUDISK_MAX_PATH_LENGTH 1024
// The size of a disk.
#define MUDISK_DISK_SIZE (MUDISK_BLOCK_SIZE * MUDISK_BLOCK_COUNT)

// Forward-declaration to hide details -- definition is in source file.
struct muDisk;
// All of the information about a specific virtual disk.
// This library needs to know the details of what is inside one, but
//   external code does not.
typedef struct muDisk MUDISK;


// Initializes a virtual disk, loading it from a real file in the real filesystem.
// Parameters:
// - pathToRealFile [in] The name of the real file to use.
// Returns: 
// - A handle for a virtual disk that is associated with the file and ready for use.
//   The caller must pass it to muDisk_close() when finished with it.
// Preconditions:
// - pathToRealFile is a valid path to a disk file that already exists.
// Errors:
// - Returns NULL and sets mueerno to ERR_MUDISK_NO_SUCH_DISK if the real file cannot be opened.
// - Returns NULL and sets muerrno to ERR_MUDISK_WRONG_DISK_SIZE if the real file is not MUDISK_DISK_SIZE.
MUDISK*
muDisk_open (const char* pathToRealFile);


// Releases resources used by a virtual disk.
// Parameters:
// - disk [inout] A handle for the virtual disk that should be closed.
// Preconditions:
// - disk was initialized by muDisk_open() and has not already been closed.
// Postconditions:
// - All resources used to model the disk have been released.  It should no longer be used.
void
muDisk_close (MUDISK* disk);


// Reads a block from a virtual disk, copying its contents into a buffer.
// Parameters:
// - disk [in] A handle for a virtual disk.
// - blockNum [in] The identifier of which block should be read.
// - buffer [out] The location that should be filled with data from disk.
// Preconditions:
// - disk is a valid handle to an open virtual disk.
// - 0 <= blockNum < MUDISK_BLOCK_COUNT
// - buffer points to a location where 1024 bytes can be written.
// Postconditions:
// - The data from the requested block has been copied to buffer.
// Returns:
// - 0 on success, -1 on failure.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUDISK_INVALID_BLOCK_NUM if the block number is invalid.
int
muDisk_read (MUDISK* disk, uint32_t blockNum, void* buffer);

// Writes a buffer to a block on a virtual disk.
// Parameters:
// - disk [in] A handle for a virtual disk.
// - blockNum [in] The identifier of which block should be written.
// - buffer [in] The data that should be written to disk.
// Preconditions:
// - disk is a valid handle to an open virtual disk.
// - 0 <= blockNum < MUDISK_BLOCK_COUNT
// - buffer points to a location where 1024 bytes can be read.
// Postconditions:
// - The data in the requested block has been copied from buffer.
// Returns:
// - 0 on success, -1 on failure.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUDISK_INVALID_BLOCK_NUM if the block number is invalid.
int
muDisk_write (MUDISK* disk, uint32_t blockNum, void* buffer);


// Creates a new virtual disk.
// Parameters:
// - pathToRealFile The name of the real file that will store the virtual disk.
// Preconditions:
// - No file with that name exists.
// - That path points to a location where a file could be created.
// Postconditions:
// - That path refers to a virtual disk file.
// Returns:
// - 0 on success, -1 on failure.
// Errors:
// - Returns -1 and sets muerrno to ERR_MUDISK_FILE_ALREADY_EXISTS if there is already a real file with that name.
// - Returns -1 and sets muerrno to ERR_MUDISK_CREATION_FAILURE if the file could not be created for any other reason.
int
muDisk_create (const char* pathToRealFile);

#endif//MUDISK_H
