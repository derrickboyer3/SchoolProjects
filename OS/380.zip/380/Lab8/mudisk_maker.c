// File: mudisk_maker.c
// Author: Chad Hogg
// Program that creates new virtual disks for MU Virtual Disk library.
// Part of the handout for mustorage1 lab in CSCI380.

#include "mudisk.h"

#include <stdio.h>
#include <stdlib.h>

int
main (int argc, char* argv[])
{
  // Confirm that we got a filename (and nothing else).
  if (argc != 2)
  {
    fprintf (stderr, "Usage: %s <filename>\n", argv[0]);
    exit (EXIT_FAILURE);
  }

  // Attempt to create the virtual disk.
  int result = muDisk_create (argv[1]);
  if (result == -1) {
    fprintf (stderr, "MUError: %d\n", muerrno);
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
