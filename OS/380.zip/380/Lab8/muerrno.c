// File: muerrno.c
// Author: Chad Hogg
// A library for noting and retrieving errors.
// Part of handout for mustorage1 lab in CSCI380, used in following labs as well.

#include "muerrno.h"

// The global variable into which our functions will write when errors occur.
int muerrno;
