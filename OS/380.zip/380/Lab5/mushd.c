/*
 * File name: mushd.c
 * Author: Derrick Boyer 380
 * Assignment: Lab 4; Writing your own shell part D
 */

/*
 * Discussion:
 * To meet the specifications for this lab, I created multiple helper
 * functions to assist in the execution of the program. The first
 * helper function was the reapZombies(int signal) helper that I wrote
 * to deal with the reaping of child process and SIGCHLD signals in 
 * Shell Part C. That did the job of reaping child processes and updating
 * globals as necessary. The second handler was the handleSIGINT(int signal)
 * function which did the job of handling when a user types CTRL-C during a
 * processes execution. It handled it by forwarding that signal to every 
 * process included in the foreground job's process group ID and printing out
 * that the process was terminated for that reason. I also included a new global
 * variable called volatile pid_t g_stoppedPid which kept track of which process
 * was stopped. This global was used the the handleSIGTSTP(int signal) function
 * which did the job of forwarding that signal to all process that were apart of
 * the foreground process's process group ID and printing out that the process was
 * stopped for that reason. Both handlers for the SIGINT and SIGTSTP signals 
 * updated globals accordingly. The final helper function was a helper to deal with 
 * the new built in fg command. This did the job of bringing stopped processes to 
 * the foreground using SIGCONT. All signal handlers were installed in main and signals
 * were blocked before appropriate processes were run to ensure Async-Signal-Safe 
 * proceedures were followed to avoid unintended corruption of data. 
 */

/*Includes and Global Variables*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <ctype.h>
#include "musys.h"
#include <signal.h>

#define MAX_INPUT_LENGTH 1024
#define MAX_TOKENS 128
volatile pid_t g_foregroundPid = 0;
volatile pid_t g_stoppedPid = 0; 

/*Helper function header declarations*/
void removeWhiteSpace(char *prompt);
void executeCommand(char *tokens[], int background);
void reapZombies(int signal);
void handleSIGINT(int signal); // Handle CTRL C
void handleSIGTSTP(int signal); // Handle CTRL Z
void handleFG (); // Handle fg


 /*Functional Code*/	

/*
 * Main method that implements the while loop pseudocode from class
 */
int main() {
    // Array for the input prompt
    char prompt[MAX_INPUT_LENGTH];

    // Install signal handler for SIGCHLD, SIGINT, SIGTSTP,
    Signal(SIGCHLD, reapZombies);
    Signal(SIGINT, handleSIGINT);
    Signal(SIGTSTP, handleSIGTSTP);

    // Infinite while loop
    while (1) {
        // Print prompt and flush the output buffer
        printf("mushd> ");
        fflush(stdout);

        // Check for end of file
        if (feof(stdin)) {
            break;
        }

        // Check for null prompt
        if (fgets(prompt, MAX_INPUT_LENGTH, stdin) == NULL) {
            break;
        }

        // Use strcspn to get rid of new line char at the end of the input
        prompt[strcspn(prompt, "\n")] = '\0';

        // Use helper function to get rid of the whitespace in the prompt
        removeWhiteSpace(prompt);

        // Check for quit command
        if (strcmp(prompt, "quit") == 0) {
            break;
        }

        // Create array for all tokens
        char *tokens[MAX_TOKENS];

        // Go through each token in the input and add it to the array of tokens
        char *token = strtok(prompt, " \t");
        int token_count = 0;
        while (token != NULL && token_count < MAX_TOKENS - 1) {
            tokens[token_count++] = token;
            token = strtok(NULL, " \t");
        }

        // Add a NULL character at the end of the tokens in the array so we know when the tokens end
        tokens[token_count] = NULL;

        // Check for background job by looking for '&' at the end
        int background = 0;
        if (token_count > 0 && strcmp(tokens[token_count - 1], "&") == 0) {
            background = 1;
            // Replace '&' with NULL
            tokens[token_count - 1] = NULL; 
        }

        // Check for fg command and if so call helper function
        if (strcmp(prompt, "fg") == 0) {
            handleFG();
        }
        // Execute command using helper function if it is not null
        else if (tokens[0] != NULL) {
            executeCommand(tokens, background);
        }
    }
    return 0;
}



/*
 * A helper function for removing the whitespace from the command prompt
 */
void removeWhiteSpace(char *prompt) {
    // Create pointer variables for the beginning and the end of the input
    char *start = prompt;
    char *end = prompt + strlen(prompt) - 1;

    // Get rid of the leading whitespace by using the isspace function
    while (isspace(*start)) {
        start++;
    }

    // Get rid of all the trailing whitespace
    while (end > start && isspace(*end)) {
        *end-- = '\0';
    }

    // Move the rest of the characters up to the beginning of the string
    if (start != prompt) {
        while (*start) {
            *prompt++ = *start++;
        }
        *prompt = '\0';
    }
}



/*
 * Helper function for executing the command prompt
 */
void executeCommand(char *tokens[], int background) {
    // Block SIGCHLD, SIGINT, and SIGTSTP signals
    sigset_t mask, prev;
    Sigemptyset(&mask);
    Sigaddset(&mask, SIGCHLD);
    Sigaddset(&mask, SIGINT);
    Sigaddset(&mask, SIGTSTP);
    Sigprocmask(SIG_BLOCK, &mask, &prev);

    // Fork to create child and parent processes
    pid_t pid = Fork();

    // Check for and handle child process
    if (pid == 0) {
        // Set the process group ID for signal handling purposes
        setpgid(pid, pid);
        // Block appropritate signals while command is being processed
	    Sigprocmask(SIG_SETMASK,&prev,NULL);
        Execvp(tokens[0], tokens);
        // Unblock signals when done
	    Sigprocmask(SIG_BLOCK, &mask, &prev);
    }
    // Handle parent process 
    else {
        // Check for and handle foreground process by waiting for child process to finish
        if (!background) {
            // For foreground jobs, wait for the child process to finish
            g_foregroundPid = pid;
            while (g_foregroundPid != 0) {
                Sigsuspend(&prev);
            }

            // Reset g_foregroundPid after the process finishes
            g_foregroundPid = 0;

        // Handle background job by printing the process ID and the command given
        // Background jobs do not have to wait for child to finish
        } else {
            // Print a message for background process
            printf("(%d) ", pid);
            for (int i = 0; tokens[i] != NULL; i++) {
                printf("%s ", tokens[i]);
            }
            printf("&\n");
        }
    }

    // Unblock SIGCHLD, SIGINT, SIGTSTP signals
    Sigprocmask(SIG_SETMASK, &prev, NULL);
}



/*
 * Helper function for reaping the child processes when the signal is sent
 */
void reapZombies(int signal) {
    int status;
    pid_t pid;

    // Save old errno to restore later
    int olderrno = errno;

    // Reap any zombie child processes until there is no more
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (pid == g_foregroundPid) {
            // Reset foreground pid
            g_foregroundPid = 0;
        }
    }

    // Reset errno
    errno = olderrno;
}



/*
 * Handler function for the SIGINT signal
 */
void handleSIGINT(int signal) {
    // Save old errno
    int olderrno = errno;

    // Check to see if there is a foreground job
    if (g_foregroundPid != 0) {
        // Send SIGINT to the entire process group of the foreground job
        Kill(-g_foregroundPid, signal);

        // Use Async-Signal-Safe print functions in handler
        safePrintString("Job (");
        safePrintInt(g_foregroundPid);
        safePrintString(") terminated by signal ");
        safePrintInt(signal);
        safePrintString("\n");

        // Update foreground pid global
        g_foregroundPid = 0;
    }

    // Restore olderrno
    errno = olderrno;
}



/*
 * Handler function for the SIGTSTP signal
 */
void handleSIGTSTP(int signal) {
    // Handle undefined behavior
    if (g_stoppedPid != 0) {
        printf("There is already a stopped job.");
        return;
    }

    // Save old errno
    int olderrno = errno;

    // Check to see if there is a foreground job
    if (g_foregroundPid != 0) {
        // Update stopped pid global
        g_stoppedPid = g_foregroundPid;

        // Send SIGTSTP to the entire process group of the foreground job
        Kill(-g_foregroundPid, signal);

        // Update foreground pid global
        g_foregroundPid = 0;

        // Use Async-Signal-Safe print functions
        safePrintString("Job (");
        safePrintInt(g_stoppedPid);
        safePrintString(") stopped by signal ");
        safePrintInt(signal);
        safePrintString("\n");
    }

    // Restore old errno
    errno = olderrno;
}

/*
 * Handler function for the fg command
 */
void handleFG() {
    // If there is a stopped job, continue it and update globals
    if (g_stoppedPid != 0) {
        // Update foreground pid global
        g_foregroundPid = g_stoppedPid;

        // Pass SIGCONT to stopped process
        Kill(-g_stoppedPid, SIGCONT);
        // Wait for process to finish before continuing
        while (g_foregroundPid != 0) {
            /*spin*/
        }
        // Update stopped pid global
        g_stoppedPid = 0;
    }
}

