/*
 * Derrick Boyer
 * Lab 08: Server Programming
 */

/* Part 1 */
CREATE FUNCTION internal_credits (stud_id VARCHAR (10))
    RETURNS INT
    LANGUAGE SQL
    AS $$
        SELECT SUM(credits) FROM takes JOIN course ON takes.course_id = course.course_id 
        WHERE grade IS NOT NULL AND grade != "F" AND id = stud_id;
    $$;

/* Part 2 */
CREATE PROCEDURE fire_instructor (old_id VARCHAR(10), new_id VARCHAR(10))
    LANGUAGE SQL
    AS $$
        UPDATE advisor SET i_id = new_id WHERE i_id = old_id;
        UPDATE teaches SET id = new_id WHERE id = old_id;
        DELETE FROM instructor WHERE id = old_id;
    $$;

/* Part 3 */
CREATE FUNCTION gpa (stu_id VARCHAR(10))
    RETURNS NUMERIC (3,2)
    LANGUAGE PLPGSQL
    AS $$
        DECLARE:
            gpatotal NUMERIC (3,2);
            totcredits NUMERIC (1,0);
            currentrow student%ROWTYPE;
        BEGIN:
            gpatotal := 0;
            for currentrow IN (SELECT DISTINCT course_id, grade, credits FROM student NATURAL JOIN takes NATURAL JOIN course WHERE grade IS NOT NULL AND id = stu_id)
                IF currentrow.grade = "A" THEN
                    gpatotal := 4 * currentrow.credits;
                ELSE IF currentrow.grade = "A-" THEN
                    gpatotal := 3.7 * currentrow.credits;
                ELSE IF currentrow.grade = "B+" THEN
                    gpatotal := 3.3 * currentrow.credits;
                ELSE IF currentrow.grade = "B" THEN
                    gpatotal := 3 * currentrow.credits;
                ELSE IF currentrow.grade = "B-" THEN
                    gpatotal := 2.7 * currentrow.credits;
                ELSE IF currentrow.grade = "C+" THEN
                    gpatotal := 2.3 * currentrow.credits;
                ELSE IF currentrow.grade = "C" THEN
                    gpatotal := 2 * currentrow.credits;
                ELSE IF currentrow.grade = "C-" THEN
                    gpatotal := 1.7 * currentrow.credits;
                ELSE IF currentrow.grade = "D+" THEN
                    gpatotal := 1.3 * currentrow.credits;
                ELSE IF currentrow.grade = "D" THEN
                    gpatotal := 1 * currentrow.credits;
                ELSE IF currentrow.grade = "D-" THEN
                    gpatotal := 0.7 * currentrow.credits;
                ELSE currentrow.grade = "F" THEN
                    gpatotal := 0 * currentrow.credits;
                END IF
                totcredits := totcredits + currentrow.credits;
            END LOOP
            RETURN gpatotal / totcredits
        END;
    $$;

/* GPA of Student with ID: 45678 = 2.01 */

/* Part 4 */
CREATE FUNCTION building_fix ()
    RETURNS TRIGGER
    LANGUAGE PLPGSQL
    AS $$
        DECLARE:
            old_buil VARCHAR(50);
            retval RECORD;
        BEGIN: 
            old_buil := "Holmes";
            IF NEW.building = old_buil THEN
                retval := NEW;
                retval.building := "Watson";
            ELSE
                retval := NEW;
            END IF;
            RETURN retval;
        END;
    $$;

CREATE TRIGGER holmes_to_watson
    BEFORE INSERT OR UPDATE ON classroom OR department
    FOR EACH ROW EXECUTE FUNCTION building_fix ();

/* Part 5 */
CREATE FUNCTION audit_instructor ()
    RETURNS TRIGGER
    LANGUAGE PLPGSQL
    AS $$
        DECLARE:
            retval RECORD;
        BEGIN: 
            retval := NEW;
            IF TG_OP = "INSERT" THEN
                INSERT INTO instructor_history VALUES (NEW.id, NEW.name, NEW.department, NEW.salary, "I", CLOCK_TIMESTAMP());
            ELSE IF TG_OP = "UPDATE" THEN
                INSERT INTO instructor_history VALUES (NEW.id, NEW.name, NEW.department, NEW.salary, "U", CLOCK_TIMESTAMP());
            ELSE
                INSERT INTO instructor_history VALUES (OLD.id, OLD.name, OLD.department, OLD.salary, "D", CLOCK_TIMESTAMP());
            END IF;
            RETURN retval;
        END;
    $$;

CREATE TRIGGER instructor_audit
    AFTER INSERT OR UPDATE OR DELETE ON instructor
    FOR EACH ROW EXECUTE FUNCTION audit_instructor ();