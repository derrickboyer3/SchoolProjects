/* Derrick Boyer */
/* Lab 04: Recursive */

/* PROBLEM 1 BEGIN */
SELECT empno, empfname
    FROM emp
    WHERE bossno IS NULL;
/* PROBLEM 1 END */

/* PROBLEM 2 BEGIN */
WITH 
wrk AS (SELECT * FROM emp),
boss AS (SELECT * FROM emp)
SELECT wrk.empno, wrk.empfname, boss.empno AS mgrno, boss.empfname AS mgrfname
    FROM wrk JOIN boss ON wrk.bossno = boss.empno
    WHERE wrk.bossno IS NOT NULL
    ORDER BY wrk.empfname ASC;
/* PROBLEM 2 END */

/* PROBLEM 3 BEGIN */
SELECT dept.deptname
    FROM emp JOIN dept ON emp.empno = dept.empno
    WHERE (SELECT AVG(empsalary)
                FROM emp
                WHERE emp.deptname = dept.deptname AND emp.empno != dept.empno) > 25000;
/* PROBLEM 3 END */

/* PROBLEM 4 BEGIN */
SELECT wrk.empno, wrk.empfname
    FROM emp AS wrk JOIN emp AS boss ON wrk.bossno = boss.empno
    WHERE wrk.bossno = (SELECT bossno FROM emp WHERE empfname = 'Andrew');
/* PROBLEM 4 END */

/* PROBLEM 5 BEGIN */
SELECT empno, empfname, empsalary
    FROM (SELECT wrk.empno, wrk.empfname, wrk.empsalary
            FROM emp AS wrk JOIN emp AS boss ON wrk.bossno = boss.empno
            WHERE wrk.bossno = (SELECT bossno FROM emp WHERE empfname = 'Andrew')) AS sub
    WHERE empsalary = (SELECT MAX(wrk.empsalary)
            FROM emp AS wrk JOIN emp AS boss ON wrk.bossno = boss.empno
            WHERE wrk.bossno = (SELECT bossno FROM emp WHERE empfname = 'Andrew'));
/* PROBLEM 5 END */

/* PROBLEM 6 BEGIN */
WITH wrk AS (SELECT * FROM emp),
boss AS (SELECT * FROM emp)
SELECT DISTINCT boss.empno, boss.empfname
    FROM wrk JOIN boss ON wrk.bossno = boss.empno
    WHERE boss.empno NOT IN (SELECT empno FROM dept);
/* PROBLEM 6 END */

/* PROBLEM 7 BEGIN */
SELECT prodid, proddesc, prodprice
    FROM product
    WHERE prodprice = (SELECT MAX(prodprice) 
                            FROM product 
                            WHERE prodid IN (SELECT subprodid FROM assembly
                                                WHERE prodid = (SELECT prodid 
                                                                    FROM product  
                                                                    WHERE proddesc = 'Animal photography kit')));

/* PROBLEM 7 END */
