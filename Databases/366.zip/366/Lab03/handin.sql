/* Derrick Boyer */
/* Lab 03: CD (full) */

/* PROBLEM 1 BEGIN */
CREATE TABLE label (
    lbltitle VARCHAR (50),
    lblstreet VARCHAR (50),
    lblcity VARCHAR (50),
    lblstate VARCHAR (50),
    lblpostcode VARCHAR (50),
    lblnation VARCHAR (50),
    PRIMARY KEY (lbltitle)
);

CREATE TABLE person (
    psnid INT,
    psnfname VARCHAR (50),
    psnlname VARCHAR (50),
    PRIMARY KEY (psnid)
);

CREATE TABLE composition (
    compid INT,
    comptitle VARCHAR (50),
    compyear INT,
    PRIMARY KEY (compid)
);

CREATE TABLE person_composition (
    psncomprole VARCHAR (50),
    psncomporder INT,
    psnid INT,
    compid INT,
    PRIMARY KEY (psncomprole, psnid, compid),
    FOREIGN KEY (psnid) REFERENCES person (psnid),
    FOREIGN KEY (compid) REFERENCES composition (compid)
);

CREATE TABLE cd (
    cdid INT,
    cdlblid VARCHAR (50),
    cdtitle VARCHAR (50),
    cdyear INT,
    lbltitle VARCHAR (50),
    PRIMARY KEY (cdid),
    FOREIGN KEY (lbltitle) REFERENCES label (lbltitle)
);

CREATE TABLE person_cd (
    psncdorder INT,
    psnid INT,
    cdid INT,
    PRIMARY KEY (psnid, cdid),
    FOREIGN KEY (psnid) REFERENCES person (psnid),
    FOREIGN KEY (cdid) REFERENCES cd (cdid)
);

CREATE TABLE recording (
    rcdid INT,
    rcdlength NUMERIC (5, 2),
    rcddate VARCHAR (50),
    compid INT,
    PRIMARY KEY (rcdid, compid),
    FOREIGN KEY (compid) REFERENCES composition (compid)
);

CREATE TABLE track (
    cdid INT,
    trknum INT,
    rcdid INT,
    compid INT,
    PRIMARY KEY (trknum, cdid),
    FOREIGN KEY (cdid) REFERENCES cd (cdid),
    FOREIGN KEY (rcdid, compid) REFERENCES recording (rcdid, compid)
);

CREATE TABLE person_recording (
    psnrcdrole VARCHAR (20),
    psnid INT,
    compid INT,
    rcdid INT,
    PRIMARY KEY (psnrcdrole, psnid, rcdid, compid),
    FOREIGN KEY (psnid) REFERENCES person (psnid),
    FOREIGN KEY (rcdid, compid) REFERENCES recording (rcdid, compid)
);
/* PROBLEM 1 END */

/* PROBLEM 2 BEGIN */
SELECT trknum, comptitle
    FROM track NATURAL JOIN composition
    WHERE cdid = (SELECT cdid FROM cd WHERE cdtitle = 'Giant Steps');
/* PROBLEM 2 END */

/* PROBLEM 3 BEGIN */
SELECT psnfname, psnlname, psnrcdrole
    FROM person_recording NATURAL JOIN person
    WHERE rcdid = (SELECT rcdid
                        FROM recording 
                        WHERE rcddate = '1959-05-04' AND compid = (SELECT compid
                                                                        FROM composition
                                                                        WHERE comptitle = 'Giant Steps'));
/* PROBLEM 3 END */

/* PROBLEM 4 BEGIN */
SELECT DISTINCT psnfname, psnlname
    FROM person_recording NATURAL JOIN person NATURAL JOIN person_composition
    WHERE psnrcdrole = 'tenor sax' AND psncomprole = 'music';
/* PROBLEM 4 END */

/* PROBLEM 5 BEGIN */
SELECT comptitle, trknum, cdtitle
    FROM cd JOIN track ON track.cdid = cd.cdid JOIN composition ON track.compid = composition.compid
    WHERE (SELECT COUNT(*) FROM track 
                           WHERE track.compid = composition.compid AND track.cdid = cd.cdid) > 1
    ORDER BY comptitle ASC, trknum ASC;
/* PROBLEM 5 END */

/* PROBLEM 6 BEGIN */
SELECT rcdid, rcddate
    FROM recording
    WHERE EXISTS (SELECT cdid 
                           FROM cd 
                           WHERE NOT EXISTS (SELECT trknum
                                          FROM track WHERE track.cdid = cd.cdid AND NOT EXISTS(
                                          SELECT psnid
                                                FROM person_recording
                                                WHERE person_recording.rcdid = recording.rcdid AND person_recording.compid = track.compid)));
/* PROBLEM 6 END */

/* PROBLEM 7 BEGIN */
SELECT rcdid, rcddate
FROM recording 
WHERE (
    SELECT COUNT(DISTINCT cdid)
        FROM track
        WHERE track.rcdid = recording.rcdid) = (SELECT COUNT(DISTINCT cd.cdid)
                                                FROM cd);
/* PROBLEM 7 END */
