/*person table info*/
CREATE TABLE person (
    person_id INT,
    fname VARCHAR (50) NOT NULL,
    mname VARCHAR (50),
    lname VARCHAR (50 NOT NULL),
    birthdate VARCHAR (10),
    PRIMARY KEY (person_id)
);

/*team table info*/
CREATE TABLE team (
    region VARCHAR (50),
    nickname VARCHAR (50),
    when_founded VARCHAR (10) NOT NULL,
    when_disbanded VARCHAR (10),
    PRIMARY KEY (region, nickname)
);

/*player table info*/
CREATE TABLE player (
    person_id INT,
    position VARCHAR (50),
    PRIMARY KEY (person_id, position),
    FOREIGN KEY (person_id) REFERENCES person (person_id)
);

/*coach table info*/
CREATE TABLE coach (
    person_id INT,
    PRIMARY KEY (person_id),
    FOREIGN KEY (person_id) REFERENCES person (person_id)
);

/*game table info*/
CREATE TABLE game (
    season VARCHAR (10),
    game_num INT,
    day_played VARCHAR (10),
    visiting_nickname VARCHAR (50),
    host_nickname VARCHAR (50),
    PRIMARY KEY (season, game_num),
    FOREIGN KEY (visiting_nickname, host_nickname) REFERENCES team (nickname)
);

/*goal table info*/
CREATE TABLE goal (
    goal_num INT,
    season VARCHAR (10),
    game_num VARCHAR (10),
    period_num VARCHAR (4),
    goal_time INT,
    goal_type VARCHAR (2),
    empty_net BOOLEAN,
    scoredBYID INT,
    assistedBYID INT,
    second_assistedBYID INT,
    PRIMARY KEY (goal_num, season, game_num),
    FOREIGN KEY (season, game_num) REFERENCES game (season, game_num),
    FOREIGN KEY (scoredBYID, assistedBYID, second_assistedBYID) REFERENCES player (person_id),
    CONSTRAINT chk_period CHECK (period_num IN ('1st', '2nd', '3rd', 'OT', 'SO')),
    CONSTRAINT chk_gt CHECK (goal_type IN ('ES', 'PP', 'SH', 'PS', 'SO'))
);

/*roster table info*/
CREATE TABLE roster (
    person_id INT,
    position VARCHAR (50),
    start_date VARCHAR (10),
    end_date VARCHAR (10),
    jersey_num VARCHAR (2),
    region VARCHAR (50),
    nickname VARCHAR (50),
    PRIMARY KEY (person_id, position, start_date),
    FOREIGN KEY (person_id) REFERENCES player (person_id),
    FOREIGN KEY (region, nickname) REFERENCES team (region, nickname)
);