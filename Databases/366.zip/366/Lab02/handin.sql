/* Derrick Boyer */
/* Lab 02: CD (basic) */

/* PROBLEM 1 BEGIN */
CREATE TABLE label (
    lbltitle VARCHAR (50),
    lblstreet VARCHAR (50),
    lblcity VARCHAR (50),
    lblstate VARCHAR (50),
    lblpostcode VARCHAR (50),
    lblnation VARCHAR (50),
    PRIMARY KEY (lbltitle)
);

CREATE TABLE cd (
    cdid INT,
    cdlblid VARCHAR (20),
    cdtitle VARCHAR (50),
    cdyear INT,
    lbltitle VARCHAR (50),
    PRIMARY KEY (cdid),
    FOREIGN KEY (lbltitle) REFERENCES label (lbltitle)
);

CREATE TABLE track (
    trkid INT,
    trknum INT,
    trktitle VARCHAR (50),
    trklength NUMERIC(5, 2), 
    cdid INT,
    PRIMARY KEY (trkid),
    FOREIGN KEY (cdid) REFERENCES cd (cdid)
);
/* PROBLEM 1 END */

/* PROBLEM 2 BEGIN */
 SELECT DISTINCT trktitle, cdtitle, trklength
    FROM track NATURAL JOIN cd
    ORDER BY cdtitle, trklength, trktitle ASC;
/* PROBLEM 2 END */

/* PROBLEM 3 BEGIN */
SELECT trktitle, trklength
    FROM track
    WHERE cdid = (SELECT cdid FROM cd WHERE cdtitle = 'Swing');
/* PROBLEM 3 END */

/* PROBLEM 4 BEGIN */
SELECT cdtitle, trktitle, trklength
    FROM cd NATURAL JOIN track
    WHERE trklength = (SELECT MAX(trklength) FROM track WHERE track.cdid = cd.cdid)
    GROUP BY cdtitle, trktitle, trklength;
/* PROBLEM 4 END */

/* PROBLEM 5 BEGIN */
SELECT cdtitle, COUNT(*), SUM(trklength)
    FROM cd NATURAL JOIN track
    GROUP BY cdtitle
    ORDER BY COUNT(*) DESC;
/* PROBLEM 5 END */

/* PROBLEM 6 BEGIN */
SELECT lbltitle, lblnation, cdtitle, SUM(trklength) AS cdlength
    FROM label NATURAL JOIN cd NATURAL JOIN track
    WHERE (SELECT SUM(trklength) FROM track WHERE track.cdid = cd.cdid) > 40
    GROUP BY lbltitle, lblnation, cdtitle;
/* PROBLEM 6 END */

/* PROBLEM 7 BEGIN */
SELECT cdtitle, trktitle, trklength 
    FROM cd NATURAL JOIN track
    WHERE trklength = (SELECT MIN(trklength) from track WHERE cd.cdid = track.cdid)
    ORDER BY trklength ASC;
/* PROBLEM 7 END */

/* PROBLEM 8 BEGIN */
CREATE VIEW CDView (cdid, cdlblid, cdtitle, cdyear, cdlength) AS
SELECT cdid, cdlblid, cdtitle, cdyear, SUM(trklength)
    FROM cd NATURAL JOIN track
    GROUP BY cdid, cdlblid, cdtitle, cdyear;
/* PROBLEM 8 END */

/* PROBLEM 9 BEGIN */
SELECT trktitle, trklength, cdtitle
    FROM track NATURAL JOIN cd
    WHERE trktitle LIKE 'C%';
/* PROBLEM 9 END */
