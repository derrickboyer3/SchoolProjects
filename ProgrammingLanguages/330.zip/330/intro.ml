(* Author:      Derrick Boyer
 * Instructor:  Dr. Cain
 * Date:        LAST MODIFICATION DATE
 * Assignment:  Lab 1 - Introduction to OCaml
 * Description: Testing various functions to get a basic undertanding of OCaml
 *)

(* BEGIN PROVIDED FUNCTIONS *)

(* explode : string -> char list
 * (explode s) is the list of characters in the string s in the order in
 *   which they appear
 * e.g.  (explode "Hello") is ['H';'e';'l';'l';'o']
 *)
let explode s =
        let rec _exp i =
                if i >= String.length s then [] else (s.[i])::(_exp (i+1)) in _exp 0;;

(* END PROVIDED FUNCTIONS *)


(* For ALL of the following method stubs (those with failwith "to be written"),
   add documentation comments including expected behavior *)


let rec sumList l = 
        match l with
        | [] -> 0
        | _ -> List.hd l + sumList (List.tl l)
;;

let rec digitsOfInt n = 
       
        match n < 10 with
        | true -> [n]
        | _ -> digitsOfInt (n / 10) @ [n mod 10]
;;

let rec additivePersistence n = 
        if n < 10 then 
                0
        else 
                1 + additivePersistence (sumList (digitsOfInt (n)))
;;

let rec digitalRoot n =
        if n < 10 then 
                n
        else 
                digitalRoot (sumList (digitsOfInt (n)))
;;

let rec listReverse l = 
        match l with
        | [] -> l
        | _ -> listReverse (List.tl l) @ List.hd l :: []
;;

let palindrome w = 
        listReverse (explode w) = explode w
;;



(* BEGIN PROVIDED FUNCTIONS *)

(* digits : int -> int list
 * (digits n) is the list of digits of n in the order in which they appear
 * in n
 * e.g. (digits 31243) is [3,1,2,4,3]
 *      (digits (-23422) is [2,3,4,2,2]
 *)
let digits n = digitsOfInt (abs n);;

(* END PROVIDED FUNCTIONS *)

(************** Add Testing Code Here ***************)

(* sum n is the sum of the numbers in the specific list
 * e.g. (sum [1;2;3;4]) is 10
 *      (sum []) is 0
 *)
 let sum n = sumList (n);;

(* digitsOfInt tests can be found above *)

(* persistence n is the amount of time we must add a numbers digits together
 * until it is less than 10
 * e.g. (persistence 9876) is 2
 *      (persistence 3) is 0
 *)
 let persistence n = additivePersistence (n);;

(* root n is the number we get at th end of adding all of the digits of a number together
 * e.g. (root 1234567) is 1
 *      (root 3) is 3
 *)
let root n = digitalRoot (n);;

(* reverse n is the reverse of a list provided
 * e.g. (reverse [9;8;7;6]) is [6;7;8;9]
 *      (reverse []) is []
 *)
let reverse n = listReverse (n);;

(* isPalindrome n tells us whether or not a word is a palindrome
 * e.g. (isPalindrome "tacocat") is true
 *      (isPalindrome "compsci") is false
 *)
 let isPalindrome n = palindrome (n);;

 (* All Test Cases Passed *)
