(* CSCI 330: Programming Assignment 5
 * misc5.ml
 *)

(* For this assignment, you may use the following library functions:

   List.map
   List.fold_left
   List.fold_right
   List.split
   List.combine
   List.length
   List.append
   List.rev

   See http://caml.inria.fr/pub/docs/manual-ocaml/libref/List.html for
   documentation.
*)



(* Do not change the skeleton code! The point of this assignment is to figure
 * out how the functions can be written this way (using fold). You may only
 * replace the   failwith "to be implemented"   part. *)



(*****************************************************************)
(******************* 1. Warm Up   ********************************)
(*****************************************************************)

(* This function takes a list of integers are adds up the square of each integer
 * by creating a function that adds the accumulated sum to the square of the
 * next element and a base of zero and passing those into a fold_left.
 * Parameters: xs - List of integers
 *)
let sqsum xs = 
  let f a x = a + x * x in
  let base = 0 in
    List.fold_left f base xs

(* This function takes in a list of functions and applies the result of each to the next,
 * acting as a pipeline operator.
 * Parameters: fs - List of functions ; s - base number to apply the first function to
 *)
let pipe fs s = 
  let f a x = x (a) in
  let base = s in
    List.fold_left f base fs

(* This function behaves the same as the above function but uses function currying.*)
let pipec fs = 
  let f a x = fun s -> x (a s) in
  let base = fun y -> y in
    List.fold_left f base fs

(* This function concatenates each element of a list with the specified separator character
 * Parameters: sep - the specified separator character ; sl - the list of elements
 *)
let rec sepConcat sep sl = match sl with 
  | [] -> ""
  | h :: t -> 
      let f a x = a ^ sep ^ x  in
      let base = h in
      let l = t in
        List.fold_left f base l

(* This function uses the above sepConcat function to create the string
 * representation of map of the given function to the given list.contents
 * Parameters: f - the function to be applied to the list ; l - the list the function is applied to
 *)
let stringOfList f l = "[" ^ sepConcat (";") (List.map (f) (l)) ^ "]"

(* This function takes two lists and creates a new list where each element is the product
 * of each element in that same position in the other two lists
 * Parameters: l1 & l2 - the two lists on which the function works
 *)
let prodLists l1 l2 =
  let f a (x1,x2) = a @ [x1 * x2] in
  let base = [] in
  let args = List.combine (l1) (l2) in
    List.fold_left f base args

(*****************************************************************)
(******************* 2. Big Numbers ******************************)
(*****************************************************************)

(* clone : 'a -> int -> 'a list 

clone takes as input x and an integer n. The result is a list of length n, where each element is x. 
If n is 0 or negative, clone will return the empty list. 

# clone 3 5;;
- : int list = [3; 3; 3; 3; 3] 
# clone "foo" 2;;
- : string list = ["foo"; "foo"]
# clone clone (-3);;
- : ('_a -> int -> '_a list) list = [])
*)
let rec clone x n = if (n <= 0) then [] else x::(clone x (n - 1))

(*
padZero : int list -> int list -> int list * int list 

padZero takes two lists: [x1,...,xn] [y1,...,ym] and adds zeros in front to make the lists equal in length. 

# padZero [9;9] [1;0;0;2];;
- : int list * int list = ([0;0;9;9],[1;0;0;2]) 
# padZero [1;0;0;2] [9;9];;
- : int list * int list = ([1;0;0;2],[0;0;9;9]) 
*)
let rec padZero l1 l2 = 
   let l1len = List.length l1 in
   let l2len = List.length l2 in
    ((clone 0 (l2len-l1len)@l1), (clone 0 (l1len-l2len)@l2))

(*
removeZero : int list -> int list 

removeZero takes a list and removes a prefix of trailing zeros. 

# removeZero [0;0;0;1;0;0;2];;
- : int list = [1;0;0;2] 
# removeZero [9;9];;
- : int list = [9;9] 
# removeZero [0;0;0;0];;
- : int list = [] 
*)

let rec removeZero l = 
  match l with
  | 0::t -> removeZero t
  | _ -> l

(* This function takes in two lists that act as representations for integers that are to large to
 * store normally and adds them together as a human would on paper (carrying numbers, etc.)
 * Parameters: l1 & l2 - the two lists on which the below function is applied
 *)
let bigAdd l1 l2 = 
  let add (l1, l2) = 
    let f (carry,a) (x1,x2) = 
      let sum = x1 + x2 + carry in
      (sum / 10, (sum mod 10) :: a)
    in
    let base = (0, []) in
    let args = List.rev (List.combine (l1) (l2)) in
    let (carry, res) = List.fold_left f base args in
      carry::res
  in 
    removeZero (add (padZero l1 l2))

(* EXTRA CREDIT BELOW *)

let rec mulByDigit i l =
  let mult (l1, l2) = 
    let f a x = failwith "to be implemented" in
    let base = failwith "to be implemented" in
    let args = failwith "to be implemented" in
    let (carry, res) = List.fold_left f base args in
      carry::res
  in 
    failwith "to be implemented"

let bigMul l1 l2 = 
  let f a x = failwith "to be implemented" in
  let base = failwith "to be implemented" in
  let args = failwith "to be implemented" in
  let (_, res) = List.fold_left f base args in
    res
