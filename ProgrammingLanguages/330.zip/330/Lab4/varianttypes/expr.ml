(* 
 * Name: Derrick Boyer
 * Date: 3/20/23
 * Course: CSCI 330 - Programming Languages
 * Assignment: Variant Types
 *
 * Assignment Attribution:
 *   This lab is based on code by Chris Stone (lab from CSE 130 by Sorin Lerner at UCSD)
 *
 * Description: A lab that produces art images and helps users gain 
 * hands-on experience with Variants and Recursive Types
 *)

let pi = 4.0 *. (atan 1.0)

type expr = 
    VarX
  | VarY
  | Sine     of expr
  | Cosine   of expr
  | Average  of expr * expr
  | Times    of expr * expr
  | Thresh   of expr * expr * expr * expr	
(* TODO: add two new "types" of expressions *)
  | Divide   of expr * expr
  | Thresh2  of expr * expr * expr * expr	

type rng = int * int -> int
type builder_fun = rng * int -> expr

(* This function takes an expression and parses it using match statements and the above
 * defined grammar to print out the string representation of the given mathematical
 * statement. 
 * Parameters: e The mathematical expression to be parsed
 * Returns: The string representation of the given mathematical expression.
 *)
let rec exprToString e =
  match e with
  | VarX -> "x"
  | VarY -> "y"
  | Sine exp -> "sin(pi*" ^ exprToString (exp) ^ ")"
  | Cosine exp -> "cos(pi*" ^ exprToString (exp) ^ ")"
  | Average (exp1, exp2) -> "((" ^ exprToString (exp1) ^ "+" ^ exprToString (exp2) ^ ")/2)"
  | Times (exp1, exp2) -> exprToString (exp1) ^ "*" ^ exprToString (exp2)
  | Thresh (exp1, exp2, exp3, exp4) ->"(" ^ exprToString (exp1) ^ "<" ^ exprToString (exp2) ^
                                      "?" ^ exprToString (exp3) ^ ":" ^ exprToString (exp4) ^ ")"
  | Divide (exp1, exp2) -> exprToString (exp1) ^ "/" ^ exprToString (exp2)
  | Thresh2 (exp1, exp2, exp3, exp4) -> "(" ^ exprToString (exp1) ^ ">" ^ exprToString (exp2) ^
                                        "?" ^ exprToString (exp3) ^ ":" ^ exprToString (exp4) ^ ")"



(* build functions:
     Use these helper functions to generate elements of the expr
     datatype rather than using the constructors directly.  This
     provides a little more modularity in the design of your program *)

let buildX()                       = VarX
let buildY()                       = VarY
let buildSine(e)                   = Sine(e)
let buildCosine(e)                 = Cosine(e)
let buildAverage(e1,e2)            = Average(e1,e2)
let buildTimes(e1,e2)              = Times(e1,e2)
let buildThresh(a,b,a_less,b_less) = Thresh(a,b,a_less,b_less)

(* TODO: add two new buildXXXXXXX functions *)
let buildDivide(e1,e2)             = Divide(e1,e2)
let buildThresh2(a,b,b_less,a_less)= Thresh2(a,b,a_less,b_less)

(* This function takes an expression and parses it using match statements and the above
 * defined grammar to evaluate the given mathematical statement. 
 * Parameters: e The mathematical expression to be parsed
 * Returns: The output of the given mathematical expression.
 *)
let rec eval (e, x, y) =
  match e with
  | VarX -> x
  | VarY -> y
  | Sine exp -> sin (pi *. eval (exp,x,y))
  | Cosine exp -> cos (pi *. eval (exp,x,y))
  | Average (exp1, exp2) -> (((eval (exp1,x,y)) +. (eval (exp2,x,y))) /. 2.)
  | Times (exp1, exp2) -> eval (exp1,x,y) *. eval (exp2,x,y)
  | Thresh (exp1, exp2, exp3, exp4) -> (if (eval (exp1,x,y) < eval (exp2,x,y)) then eval (exp3,x,y) else eval (exp4,x,y))
  | Divide (exp1, exp2) -> eval (exp1,x,y) /. eval (exp2,x,y)
  | Thresh2 (exp1, exp2, exp3, exp4) -> (if (eval (exp1,x,y) > eval (exp2,x,y)) then eval (exp3,x,y) else eval (exp4,x,y))

(* (eval_fn e (x,y)) evaluates the expression e at the point (x,y) and then
 * verifies that the result is between -1 and 1.  If it is, the result is returned.  
 * Otherwise, an exception is raised.
 *)
let eval_fn e (x,y) = 
  let rv = eval (e,x,y) in
  assert (-1.0 <= rv && rv <= 1.0);
  rv

let sampleExpr =
      buildCosine(buildSine(buildTimes(buildCosine(buildAverage(buildCosine(
      buildX()),buildTimes(buildCosine (buildCosine (buildAverage
      (buildTimes (buildY(),buildY()),buildCosine (buildX())))),
      buildCosine (buildTimes (buildSine (buildCosine
      (buildY())),buildAverage (buildSine (buildX()), buildTimes
      (buildX(),buildX()))))))),buildY())))

let sampleExpr2 =
  buildThresh(buildX(),buildY(),buildSine(buildX()),buildCosine(buildY()))




(******************* Functions you need to write **********)

(* build: (int*int->int) * int -> Expr 
   Build an expression tree.  The second argument is the depth, 
   the first is a random function.  A call to rand(2,5) will give
   you a random number in the range [2,5)  
   (2 inclusive, and 5 exclusive).

   Your code should call buildX, buildSine, etc. to construct
   the expression.
*)

(* This function takes in a tuple where the first element is a random object that is used for
 * decision making in the pattern matching, and a depth which determines how many times this
 * function is recursively called. If the depth is 0 then it knows it cannot generate complicated 
 * expressions requiring sub expressions so it builds either X or Y. Otherwise it builds one of the
 * many options for the complex expressions which all require sub expressions. 
 *)
let rec build (rand,depth) = 
  if depth = 0 then
    let rand1 = rand (1,3) in
    match rand1 with
    | 1 -> buildX ()
    | _ -> buildY ()
  else
    let rand2 = rand (1,6) in
    match rand2 with
    | 1 -> buildSine (build (rand, depth-1))
    | 2 -> buildCosine (build (rand, depth-1))
    | 3 -> buildAverage ((build (rand, depth-1)), (build (rand, depth-1)))
    | 4 -> buildTimes ((build (rand, depth-1)), (build (rand, depth-1)))
    | _ -> buildThresh ((build (rand, depth-1)), (build (rand, depth-1)), (build (rand, depth-1)), (build (rand, depth-1)))

    (* This function behaves the same as build except it has the added build options for the additional
     * expressions that I added to the grammar, eval, and exprToString. 
     *)
let rec build2 (rand,depth) = 
  if depth = 0 then
    let rand1 = rand (1,3) in
    match rand1 with
    | 1 -> buildX ()
    | _ -> buildY ()
  else
    let rand2 = rand (1,8) in
    match rand2 with
    | 1 -> buildSine (build (rand, depth-1))
    | 2 -> buildCosine (build (rand, depth-1))
    | 3 -> buildAverage ((build (rand, depth-1)), (build (rand, depth-1)))
    | 4 -> buildTimes ((build (rand, depth-1)), (build (rand, depth-1)))
    | 5 -> buildThresh ((build (rand, depth-1)), (build (rand, depth-1)), (build (rand, depth-1)), (build (rand, depth-1)))
    | 6 -> buildDivide ((build (rand, depth-1)), (build (rand, depth-1)))
    | _ -> buildThresh2 ((build (rand, depth-1)), (build (rand, depth-1)), (build (rand, depth-1)), (build (rand, depth-1)))


(* g1,c1 : unit -> ((int*int->int) * int -> Expr) * int * int * int
 * these functions should return the parameters needed to create your 
 * top color / grayscale pictures.
 * they should return (function,depth,seed1,seed2)
 * Function should be build or build2 (whichever you used to create
 * the image)
 *)

 (*Below are the parameters I used to create my images*)
let g1 () = (build, 8, 3, 33)  

let c1 () = (build, 8, 3, 33)