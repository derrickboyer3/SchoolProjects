(* CSCI 330: OCaml Lab 3
 * misc3.ml
 * Derrick Boyer
 * Dr. Cain
 * 3/1/23
 *)

(* ***** DOCUMENT ALL FUNCTIONS YOU WRITE OR COMPLETE ***** *)

(* A function that takes in a tuple as a paramter and checks to see if they key k is in the
 * list l and if so return the value associated with that key v. If k does not exist it returns the 
 * default value d.
 *)
let rec assoc (d,k,l) = 
    match l with
    | h::t -> let (key,v) = h in if key = k then v else assoc (d,k,t)
    | [] -> d
;;

(* A function that takes in a list l as a parameter and goes through and removes all the duplicate
 * values in the given list.
 *)
(* fill in the code wherever it says : failwith "to be written" *)
let removeDuplicates l = 
  let rec helper (seen,rest) = 
      match rest with 
        [] -> seen
      | h::t -> 
        let seen' = if List.mem h seen then seen else h :: seen in
        let rest' = t in 
	  helper (seen',rest') 
  in
      List.rev (helper ([],l))

(* A function that represents a while loop. While c' is true the loop will continue and when it
 * is false it will return the updated value of b
 *)
(* Small hint: see how ffor is implemented below *)
let rec wwhile (f,b) = 
  let (b', c') = f(b) in 
  if c' then wwhile (f,b')
  else b'
;;

(* A function that takes in a tuple (f,b) as a parameter and updates b with f(b) until
 * b = f(b) using the above wwhile loop.
 *)
(* fill in the code wherever it says : failwith "to be written" *)
let fixpoint (f,b) = wwhile ((fun x -> (f x, f x != x)), b)


(* ffor: int * int * (int -> unit) -> unit
   Applies the function f to all the integers between low and high
   inclusive; the results get thrown away.
 *)

let rec ffor (low,high,f) = 
  if low>high 
  then () 
  else let _ = f low in ffor (low+1,high,f)
