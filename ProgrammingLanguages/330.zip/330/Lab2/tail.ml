(* CSCI 330: Lab 2
 * misc.ml
 * Derrick Boyer
 * Dr. Cain
 * 2/14/23
 * Practice with implementing functions tail recursively
 *)

(* 
	***** PROVIDE COMMENT BLOCKS AND IMPLEMENTATIONS FOR THE FOLLOWING FUNCTIONS ***** 
	***** INCLUDE TYPE SIGNATURES ***** 
*)

(* A function that takes in a tolerance and a number as its parameters and returns
 * the approximated square root of that number within the tolerance specified
 * Parameters: float tol (the tolerance); int x (the number on which to calculate the sqrt)
 * Returns: The square root of the given number within a specified tolerance
 *)
let rec sqrt tol x = 
	let rec sqrtHelper tol y x =
		if abs_float (y -. ((y +. (x /. y)) /. 2.0)) < tol then
			y
		else
			sqrtHelper (tol) (abs_float ((y +. x /. y) /. 2.0)) (x)
	in sqrtHelper tol 1.0 x
;;

(* A version of the above square root function that has a hard coded tolerance
 * of 0.0001 for any number passed in.
 * Parameters: None
 * Returns: The square root of the given number within a tolerance of 0.0001
 *)
(* Your solution for sqrt2 should not need a lambda. Replace
   everything to the right of the =. *)
let rec sqrt2 = 
	sqrt (0.0001)
;;

(* A basic function to solve for the factorial of a number using if/else
 * statements. It takes in an int as a parameter.
 * Parameters: int x (The number on which to calculate the factorial)
 * Returns: The factorial of the specified number
 *)
let rec factorial1 x = 
	if x = 1 then
		1
	else
		x * factorial1 (x - 1)
;;

(* A basic function to solve for the factorial of a number using pattern
 * matching. It takes in an int as a parameter.
 * Parameters: int x (The number on which to calculate the factorial)
 * Returns: The factorial of the specified number
 *)
let rec factorial2 x =
	match x = 1 with
	| true -> 1
	| _ -> x * factorial2 (x - 1)
;;

(* A tail recursive function to solve for the factorial of a number using 
 * if/else statements. It takes in an int as a parameter.
 * Parameters: int x (The number on which to calculate the factorial)
 * Returns: The factorial of the specified number
 *)
let factorial3 x = 
	let rec factorialHelper total x =
		if x = 1 then
			total
		else
			factorialHelper (total * x) (x - 1)
	in factorialHelper 1 x
;;

(* A tail recursive function that solves for the nth fibonacci number
 * It takes in an int as a parameter.
 * Parameters: int x (The number n in the fibonacci sequence to calculate up to)
 * Returns: The nth fibonacci number
 *)
let fibonacci x = 
	let rec fibonacciHelper prev current x =
		match x with
		| 0 -> prev
		| _ -> fibonacciHelper (current) (current + prev) (x - 1)
	in fibonacciHelper 0 1 x
;;

(* A basic function to reverse the contents of a list
 * It takes in a list as a parameter.
 * Parameters: List l (The list to reverse)
 * Returns: A reversed version of l
 *)
let rev l = 
	let rec revHelper l1 l2 =
		match l1 with
		| [] -> l2
		| _ -> revHelper (List.tl l1) (List.hd l1 :: l2)
	in revHelper l []
;;

(* A function that takes in a function and a list and returns a list
 * of all the items in the original list applied to that function.
 * Parameters: function f (the function to apply to the list)
 *             List l (the list that the function is applied to)
 * Returns: List of the results from applying the function to the list
 *)
let rec map f l = 
	match l with
	| [] -> []
	| _ -> f (List.hd l) :: map (f) (List.tl l)
;;

(* A tail recursive function that takes in a function and a list and returns a list
 * of all the items in the original list applied to that function.
 * Parameters: function f (the function to apply to the list)
 *             List l (the list that the function is applied to)
 * Returns: List of the results from applying the function to the list
 *)
let map2 f l = 
	let rec map2Helper f l1 l2 =
		match l1 with
		| [] -> rev (l2)
		| hd :: tl -> map2Helper (f) (tl) ((f hd) :: l2)
	in map2Helper f l []
;;

(* A function that creates a list of all the numbers between a given interval
 * It takes in two integers as its parameters and returns a list.
 * Parameters: int a (the lower bound of the range) int b (the upper bound of the range)
 * Returns: List of all numbers in specified range
 *)
let rec range a b = 
	if b < a then
		[]
	else
		[a] @ range (a+1) (b)
;;

(* A function that computes for all the square roots of the numbers 1-20
 * and stores them in a list.
 * Parameters: None
 * Returns: List of all square roots
 *)
let roots : float list = 
	map (sqrt2) ([1.;2.;3.;4.;5.;6.;7.;8.;9.;10.;11.;12.;13.;14.;15.;16.;17.;18.;19.;20.])
;;
