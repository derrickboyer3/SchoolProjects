/*
 In general, your program should be split up into different sections

 Section 0: Top Comment Block
   Always include the following:
   - First and last name
   - Last date of modification
   - Course + Section
   - Assignment Name
   - File Description

 Section 1: Includes (must be in the following order)
   1. C++ standard library includes (e.g. <algorithm>)
   2. C library includes (e.g. <math.h> or <cmath>)
   3. System library includes (<name.h> but are not part of the C or C++ standard)
   4. User includes (ones contained in quotes -- e.g. "Timer.hpp")

 Section 2: Preprocessor Definitions
   - Anything that starts with #define (or appropriate guards around it

 Section 3: Compile-time constants, type aliases, using directives, type definitions
   - constexpr Type name = value-expr;
   - using Type = type-expr;
   - using std::cout;
   - declarations of file-scoped struct/class/union

 Section 4: Global variables -- NOTE: use sparingly and ONLY if necessary

 Section 5: Forward declarations for non-template functions
   - A forward declaration is a function without a body.
   - Any default parameters MUST be specified in the forward declaration

 Section 6: Template function implementations
   - Any functions beginning with 'template <...>'

 Section 7: main() function implementation [[[entry point of program]]]
   - main must always have the following signature:
     int main (int argc, char* argv[])

 Section 8: Implementations of non-template functions
   - Must be listed in the SAME ORDER as the forward declarations above
   - REMINDER: whenever you update the parameter types/counts, update
     them in BOTH locations. Otherwise you can get a compiler error!
*/

// Author: Professor William Killian
// Date: 2019 May 17
// Class: CSCI 362.93 - Data Structures
// Assignment: 2a - Analyzing Sorting Algorithms
//
// A high-level description of what this file provides/does should go here


// Includes
////////////////////////////////////////////////////////////////////////////////



// TODO: add include you may use here

#include "sort.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <random>
#include <algorithm>


// Forward declarations
////////////////////////////////////////////////////////////////////////////////

using std::cout;
using std::cin;
using std::endl;
using std::string;


// Main
////////////////////////////////////////////////////////////////////////////////

int
main (int argc, char* argv[])
{
  size_t n;
  string algorithm;
  char type;
  cout << "N         ==> ";
  cin >> n;
  cout << "Algorithm ==> ";
  cin >> algorithm;
  cout << "Type      ==> ";
  cin >> type;
  std::vector <int> a;
  Statistics s;

  //***********************************************************************************************
  //Ascending population
  if (type == 'a')
  {
    //populate vector
    for (size_t i = 0; i < n; i++)
    {
      a.push_back (i);
    }
  }

  //************************************************************************************************
  //Descending population
  if (type == 'd')
  {
    //populate vector
    for(size_t i = 0; i < n; i++)
    {
      a.push_back (n - i);
    }
  }

  //****************************************************************************************************
  //Random population
  if (type == 'r')
  {
    size_t seed;
    cout << "Seed      ==> ";
    cin >> seed;
    std::minstd_rand rando (seed);
    //populate vector
    for(size_t i = 0; i < n; i++)
    {
      a.push_back (rando ());
    }
  }

  //*****************************************************************************************************
    //make copy
    std::vector <int> aCopy;
    for(size_t i = 0; i < a.size (); i++)
    {
      aCopy.push_back (a.at (i));
    }

  //****************************************************************************************************
  //Bubble sort
  if (algorithm == "bubble")
  {
    //sort vector
    bubbleSort (a, s);
  }

  //****************************************************************************************************
  //Insertion Sort
  if (algorithm == "insertion")
  {
    //sort vector
    insertionSort (a, s);
  }

  //***************************************************************************************************
  //Selection Sort
  if (algorithm == "selection")
  {
    //sort vector
    selectionSort (a, s);
  }

  std::sort (aCopy.begin (), aCopy.end ());
  //aCopy.sort ();
  

  cout << "\n# Compares: " << s.numCompares << endl;
  cout << "# Swaps   : " << s.numSwaps << endl;
  cout << "Sort ok?    ";
  if(a == aCopy)
  {
    cout << "yes" << endl;
  }
  else
  {
    cout << "no" << endl;
  }

}

// Function implementations
////////////////////////////////////////////////////////////////////////////////
