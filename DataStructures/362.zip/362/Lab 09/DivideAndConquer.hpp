// File: DivideAndConquer.hpp
// Author: Gary Zoppetti and Will Killian and Chad Hogg and Derrick Boyer
// CSCI 362-f22
// Last modified 11/28/22
// Assignment Name: Advanced Sorts
// Uses a variety of divide and conquer algorithms split up into their separate functions to sort data

#ifndef DIVIDE_AND_CONQUER_HPP_
#define DIVIDE_AND_CONQUER_HPP_

#include <iterator>
#include <utility>
#include <vector>
#include <algorithm>

// NOTE: you are forbidden from using anything from <algorithm> for this assignment
//       EXCEPT for std::copy

namespace SortUtils
{

// [9]
// Given a RandomAccessRange [first, last), determine where the "midpoint"
// would be and perform the following steps:
// order *first, *mid, *std::prev(last) in such a way such that
//   *first <= *mid <= *std::prev(last)
//
// returns an iterator to mid -- a.k.a. the median
//
template<typename Iter>
Iter
median3 (Iter first, Iter last)
{
  // TODO
  //find the median index and create the median iterator
  auto median = std::distance (first, last) / 2;
  auto iter = first;
  for (long i = 0; i < median; i++)
  {
    iter++;
  }

  //create variables for all the iterators' values
  auto smallest = *first;
  auto middle = *iter;
  auto biggest = *std::prev(last);

  //change first's and iter's values to their appropriately sorted values
  if (*first > *iter)
  {
    smallest = *iter;
    middle = *first;
  }
  *first = smallest;
  *iter = middle;

  //change iter's and std::prev(last)'s values to their appropriately sorted values
  if (*iter > *std::prev(last))
  {
    middle = *std::prev(last);
    biggest = *iter;
  }
  *iter = middle;
  *std::prev(last) = biggest;

  //change first's and iter's values to their appropriately sorted values now that the largest is guaranteed to be at the end
  if (*first > *iter)
  {
    smallest = *iter;
    middle = *first;
  }
  *first = smallest;
  *iter = middle;

  //return iterator to median
  return iter;
}

// [10]
// Takes two sorted ranges [first1, last1) and [first2, last2)
// and "merges" them by copying values into the iterator starting
// at "out". Uses operator< for comparing values
//
// Returns the iterator of one-past-the-last where we wrote to out
//
template<typename Iter1, typename Iter2, typename OIter>
OIter
merge (Iter1 first1, Iter1 last1, Iter2 first2, Iter2 last2, OIter out)
{
  // TODO
  //check that first1 and first2 both don't equal their last iterators
  while (first1 != last1 || first2 != last2)
  {
    //if first1 == last1 then that means the only numbers 
    //not added to out are in the second half so add first2 and increment
    if(first1 == last1)
    {
      *out = *first2;
      first2++;
      out++;
    }
    //if first2 == last2 then that means the only numbers 
    //not added to out are in the first half so add first1 and increment
    else if (first2 == last2)
    {
      *out = *first1;
      first1++;
      out++;
    }
    //first1 and first2 don't equal their lasts so compare and add to out appropriately
    else
    {
      if (*first1 < *first2)
      {
        *out = *first1;
        first1++;
        out++;
      }
      else if (*first1 > *first2)
      {
        *out = *first2;
        first2++;
        out++;
      }
      else
      {
        *out = *first1;
        first1++;
        out++;
        *out = *first2;
        first2++;
        out++;
      }
    }
  }
  return out;
}

// [15]
// Takes a RandomAccessRange [first, last) and partitions the data into
// three groups -- this should be accomplished in a SINGLE PASS Big-O: O(N)
//
// Group 1: all values in [first, last) < pivot
// Group 2: all values in [first, last) == pivot
// Group 3: all values in [first, last) > pivot
//
// [ ... Group 1 ... | ... Group 2 ... | ... Group 3 ... ]
//                   ^                 ^
//                   p1                p2
//
// Returns a pair of iterators pointing to "p1" and "p2" above
//
// Hint: See separate Three Way Partition explanation in handout.
//
template<typename Iter, typename Value>
std::pair<Iter, Iter>
partition (Iter first, Iter last, Value const& pivot)
{
  // TODO
  //create veriables for all the parameter values
  auto lo = first;
  auto eq = first;
  auto hi = last;
  auto pivotdummy = pivot;

  //while we haven't sorted everything loop through until everything is sorted
  while (eq != hi)
  {

    //if the number is less than the pivot then swap lo with eq and increment both
    if (*eq < pivotdummy)
    {
      auto temp = *lo;
      *lo = *eq;
      *eq = temp;
      lo++;
      eq++;
    }

    //if the number is greater than the pivot decrement hi and swap eq and hi
    else if (*eq > pivotdummy)
    {
      hi--;
      auto temp = *hi;
      *hi = *eq;
      *eq = temp;
    }

    //otherwise just increment eq
    else
    {
      eq++;
    }
  }

  //return the value at the front of the middle section and the end of the middle section
  return std::pair<Iter, Iter> (lo, eq);
}

// [10]
// Given a RandomAccessRange, recursively call partition on either the
// left half or right half until you have found the nth largest element
//
// A call to nth_element (v.begin(), v.end(), 0) will return the min
// A call to nth_element (v.begin(), v.end(), v.size() - 1) will return the max
// A call to nth_element (v.begin(), v.end(), v.size() / 2) will return the median
//
// Precondition:
//   std::distance (begin, end) > n
//
// Hints:
//  - n will change if you need to recurse on the right half
//  - No recursion happens if "index of" n is between "index of" p1 and p2
//    remember: p1 and p2 are the return values to partition.
//  - call median3 to get a pivot value
//  - when calling partition, remember to dereference the iterator returns by median3
//
template<typename Iter>
Iter
nth_element (Iter first, Iter last, size_t n)
{
  // TODO
  // auto [p1, p2] = SortUtils::partition (...);
  
  //check precondition
  if (std::distance (first, last) > 0)
  {

    //get the median and partition the elements
    auto iter = SortUtils::median3 (first, last);
    auto [p1, p2] = SortUtils::partition (first, last, *iter);

    //get the indexes of p1 and p2
    size_t index1 = std::distance (first, p1);
    size_t index2 = std::distance (first, p2);

    //if n is between p1 and p2 just return p1 because all elements between p1 and p2 are equal
    if (n >= index1 && n < index2)
    {
      return p1;
    }

    //if n is greater than p2 recurse on the third section and
    //make sure to decrease n by p2
    else if (n >= index2)
    {
      return SortUtils::nth_element (p2, last, n - index2);
    }

    //otherwise recurse in the front section
    else
    {
      return SortUtils::nth_element (first, p1, n);
    }
  }

  //preconditions not met
  else
  {
    return first;
  }
}

// [10]
// Given a RandomAccessRange, sort using merge sort
//
// Precondition:
//   std::distance (begin, end) > 0
//
// Hints:
//   - You will need a vector to act as a temporary buffer.
//   - The merge function will expect that vector to already be big enough
//     to hold all of the elements.
//
template<typename Iter>
void
merge_sort (Iter first, Iter last)
{
  // TODO
  // T is the type of data we are sorting
  using T = std::remove_reference_t<decltype (*std::declval<Iter> ())>;

  //base case
  if (first == last || std::distance (first, last) == 1)
  {
    return;
  }

  //create first1 and last1 variables
  auto first1 = first;
  auto last1 = first;

  //move last1 to the median
  for (long i = 0; i < std::distance (first, last) / 2; i++)
  {
    last1++;
  }

  //create first2 and last2 variables
  auto first2 = last1;
  auto last2 = last;

  //create the vector to print into and the iterator at the beginning
  std::vector<T> vec (std::distance (first, last));
  auto iter = vec.begin ();

  //recurse on both halves
  SortUtils::merge_sort (first1, last1);
  SortUtils::merge_sort (first2, last2);

  //after sorting each half merge the two halves
  SortUtils::merge (first1, last1, first2, last2, iter);
  iter = vec.begin ();

  //copy into original vector
  while (first != last)
  {
    *first = *iter;
    first++;
    iter++;
  }
}

// Provided for you -- no need to change.
template<typename Iter>
void
insertion_sort (Iter first, Iter last)
{
  for (Iter i = first; i != last; ++i)
  {
    for (Iter j = i; j != first; --j)
    {
      if (*(j - 1) > *j)
      {
        std::iter_swap (j - 1, j);
      }
      else
      {
        break;
      }
    }
  }
}


// [10]
// Given a RandomAccessRange, sort using quick sort
//
// Precondition:
//   std::distance (begin, end) > 0
//
// Hints:
//   - median3 will be called to find the pivot
//   - remember to dereference the iterator returned by median3 to get the pivot value
//   - partition should be called
//   - if there are fewer than 16 elements, use the provided insertion sort instead
//
template<typename Iter>
void
quick_sort (Iter first, Iter last)
{
  // TODO
  // T is the type of data we are sorting
  //using T = std::remove_reference_t<decltype (*std::declval<Iter> ())>;

  //if the vector has less than 16 elements than just use insertion sort
  if (std::distance (first, last) < 16)
  {
    SortUtils::insertion_sort (first, last);
  }

  //use quick sort
  else
  {

    //get the median and partition the elements
    auto iter = SortUtils::median3 (first, last);
    auto [p1, p2] = SortUtils::partition (first, last, *iter);

    //recurse until it gets low enough to just sort with insertion sort.
    SortUtils::quick_sort (first, p1);
    SortUtils::quick_sort (p2, last);
  }
}

} // end namespace util

#endif
