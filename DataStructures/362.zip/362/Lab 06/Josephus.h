#ifndef JOSEPHUS_H
#define JOSEPHUS_H

int
josephus (int n, int k);

#endif
