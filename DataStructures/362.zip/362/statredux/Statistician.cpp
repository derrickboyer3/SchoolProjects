/***************************************************
 Name: Your Name
 Course: 
 Date: 
 Assignment: 
 Description: 
 
 ***************************************************/

// TODO: other includes go here

#include "Statistician.h"
#include <iostream>
#include <vector>

/***************************************************/
//Using declarations:

using std::cout;
using std::cin;

// Function Implementations
// **************************************************

// Finds the largest value in the passed vector
// Assumes nums is not empty
float
maximum (const std::vector<float>& nums)
{
	float f = nums[0];
	for(size_t i = 1; i < nums.size (); i++)
	{
		if (nums[i] > f)
		{
			f = nums[i];
		}
	}
	return f;
}


// Finds the largest value in the passed vector
// Assumes nums is not empty
float
minimum (const std::vector<float>& nums)
{
	float f = nums [0];
	for (size_t i = 1; i < nums.size (); i++)
	{
		if (nums[i] < f)
		{
			f = nums[i];
		}
	}
	return f;
}


// Finds the sum of values from the passed vector
// Should return zero if the vector is empty
float
sumOfValues (const std::vector<float>& nums)
{
	float sum = 0.0;
	for (size_t i = 0; i < nums.size (); i++)
	{
		sum = sum + nums[i];
	}
	return sum;
}


// Finds the average of all values from the passed vector
// assumes nums is not empty
float
average (const std::vector<float>& nums)
{
	return sumOfValues (nums) / nums.size ();
}

// Creates and returns a new vector. Reads in count number
// of values from the user by prompting for each one
// should return an empty vector if count <= 0
std::vector<float>
populate (int count)
{
	std::vector<float> result;
	for (int i = 1; i <= count; i++)
	{
		cout << "Enter value ==> ";
		float f;
		cin >> f;
		result.push_back(f);
	}
	return result;
}
