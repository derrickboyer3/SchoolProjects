/***************************************************
 Name: Your Name
 Course: 
 Date: 
 Assignment: 
 Description: 
 
 ***************************************************/

// Include Directives
// **************************************************
#include <iostream>
// TODO: other includes go here

#include "Statistician.h"

// Using Statements
// **************************************************
using std::cout;
using std::cin;
using std::endl;
// TODO: any extra using statements would go here

// Forward Declarations
// **************************************************

// TODO: any functions you implement AFTER main must be defined here


// Main
// **************************************************

int
main(int argc, char* argv[])
{
    cout << "Enter number of values ==> ";
    int count;
    cin >> count;
    std::vector<float> nums = populate (count);
    cout << "\nThe statistics of all " << count << " values are:" << endl;
    cout << "  Sum: " << sumOfValues (nums) << "\n";
    cout << "  Avg: " << average (nums) << "\n";
    cout << "  Min: " << minimum (nums) << "\n";
    cout << "  Max: " << maximum (nums) << "\n";
    return EXIT_SUCCESS;

}


// Function Implementations
// **************************************************

// TODO: any functions you call within main that are a part of this
// file must be implemented AFTER main
