///////////////////////////////////////////////////////////////////////////////////////////////
// Name: Derrick Boyer
// Date: 11/4/22
// Assignment: CSCI 362-f22 Lab 07 Sieve of Erotosthenes
// Description: Write a program that implements and simulates the primes sieve of Erotosthenes
///////////////////////////////////////////////////////////////////////////////////////////////


// Includes:
#include <set>
#include <vector>
#include <iostream>
#include "Timer.hpp"
#include <string>


//Using declarations:
using std::set;
using std::vector;
using std::cout;
using std::endl;
using std::string;


/* Simulate the primes sieve of Erotosthenes using a set implementation.
 * 
 * @param N The number to which we are finding the primes up to.
 * 
 * @return a set of all the prime numbers up to the number given.
 * 
 */
set<unsigned>
sieveSet (unsigned N)
{
    set<unsigned> primes;
    for (unsigned i = 2; i <= N; ++i)
    {
        primes.insert (i);
    }
    for (auto iter = primes.begin (); iter != primes.end (); ++iter)
    {
        unsigned p = *iter;
        for (unsigned c = p + p; c <= N; c += p)
        {
            primes.erase (c);
        }
    }
    return primes;
}

/* Simulate the primes sieve of Erotosthenes using a vector implementation.
 * 
 * @param N The number to which we are finding the primes up to.
 * 
 * @return a set of all the prime numbers up to the number given.
 * 
 */
set<unsigned>
sieveVector (unsigned N)
{
    vector<bool> primes (N, true);
    for (unsigned i = 2; i <= N; ++i)
    {
        for (unsigned c = i + i; c <= N; c += i)
        {
            primes[c] = false;
        }
    }
    set<unsigned> primesSet;
    for (unsigned i = 2; i <= N; ++i)
    {
        if (primes[i] != false)
        {
            primesSet.insert (i);
        }
    }
    return primesSet;
}

int
main (int argc, char *argv[])
{
    string arg2 = argv[1];
    unsigned N = atoi (argv[2]);
    set<unsigned> primes;
    Timer time;
    if (arg2 == "set")
    {
        primes = sieveSet (N);
    }
    if (arg2 == "vector")
    {
        primes = sieveVector (N);
    }
    size_t count = primes.size ();
    time.stop ();
    double timePassed = time.getElapsedMs ();
    cout << "Pi[" << N << "] = " << count << " (using a " << arg2 << ")" << endl;
    cout << "Time: " << timePassed << " ms" << endl;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* FINDINGS:
 N       10,000,000    20,000,000   40,000,000
=============================================
set       18,770.87     41,922.3     97,466.1 (ms)
vector       447.31       992.27     2,143.24 (ms)

DISCUSSION:
The vector implementation of the Sieve of Erotosthenes was significantly faster than the set implementation.
On average the set implementation was approx. 43 times slower than the vector implementation.
This can be attributed to relative unorderedness of the set as compared to the relative orderedness of the vector.
Vectors also use less memory and because you know how big the vector is going to be it does not need to grow or shrink,
which is one of the downsides to using vectors.
 */
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 