
/*
  Filename: cdinterest.cc
  Author: Derrrick M Boyer
  Course: CSCI 362-02
  Assignment: Lab 01
  Description: Creating a program in C++ that calulates the return on a
                certificate of deposit.
*/

/**********************************************************************/
//Include Specifications

#include <iostream>
#include <string>

/*********************************************************************/
//Using Specifications

using std::cout;
using std::cin;
using std::endl;

/*********************************************************************/

void
printIntro ();

void 
printTable (int numRows, double balance, double rate);

void 
printRow (int rowNum, double balance, double rate);

double 
calcInterest (double balance, double rate);

int
main(int argc, char* argv[])
{
    printIntro ();
    cout << "Please enter the initial balance: ";
    double balance;
    cin >> balance;
    cout << "Please enter the interest rate: ";
    double rate;
    cin >> rate;
    cout << "Please enter the number of years: ";
    int numRows;
    cin >> numRows;
    cout << "\n";
    printTable (numRows, balance, rate);
    return EXIT_SUCCESS;
}

void
printIntro ()
{
    cout << "This program will calculate the interest earned\n";
    cout << "\t on a CD over a period of several years.\n\n";
}

void 
printTable (int numRows, double balance, double rate)
{
    printf("%4s%12s%13s%16s\n", "Year", "Balance", "Interest", "New Balance");
    printf("%4s%12s%13s%16s\n", "----", "-------", "--------", "-----------");
    for(int i = 1; i <= numRows; i++)
    {
        printRow(i, balance, rate);
        balance = balance + calcInterest(balance, rate);
    }
}

void 
printRow (int rowNum, double balance, double rate)
{
    double addition = calcInterest(balance, rate);
    printf("%4d%12.2f%13.2f%16.2f\n", rowNum, balance, addition, balance + addition);
}

double 
calcInterest (double balance, double rate)
{
    rate = rate * .01;
    return balance * rate;
}
