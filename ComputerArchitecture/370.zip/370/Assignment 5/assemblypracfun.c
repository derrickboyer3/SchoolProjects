#include <iostream>

int
fib (int n) {
    if (n < 0) {
        n = -n;
    }
    if (n <= 1) {
        return 1;
    }
    int t0 = 1;
    int t1 = 1;
    int t2 = 2;
    int test = 3;
    while (test <= n) {
        int temp = t1;
        t1 = t2;
        t0 = temp;
        t2 = t1 + t0;
        test++;
    }
    return t2;
}

int
zeros (int n) {
    int result = 0;
    int compare = 1;
    int bits = 32;
    while (bits != 0) {
        if ((n & compare) == 0) {
            result++;
        }
        n = n >> 1;
        bits--;
    }
    return result;
}

int
main () {
    int result = fib (1) - zeros (1);
    std::cout << result;
}